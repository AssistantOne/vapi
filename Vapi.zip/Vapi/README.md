# Aventus Voice Hub - Call Management System

A comprehensive web-based dashboard for managing calls with user authentication, real-time statistics, call analytics, and campaign management.

## Features

- 🔐 **User Authentication**: Secure login and registration system
- 📊 **Real-time Dashboard**: Live statistics and call analytics
- 📞 **Call Management**: View, search, and make new calls
- 📈 **Interactive Charts**: Call activity and disposition analytics
- 🔍 **Call Details**: View detailed call information and transcripts
- 📱 **Responsive Design**: Works on desktop and mobile devices
- 🎨 **Modern UI**: Beautiful and intuitive user interface
- 📋 **Campaign Management**: Create and manage calling campaigns
- 👥 **Contact Management**: Add contacts with full details (name, address, etc.)
- 📁 **File Upload**: Import contacts from CSV and Excel files
- 🌍 **International Support**: Make calls to any country with proper formatting

## Screenshots

### Dashboard Overview
- Statistics cards showing total, successful, pending, and failed calls
- Interactive charts for call activity and dispositions
- Searchable and sortable calls table
- Real-time data updates

### Call Management
- Make new calls with phone number input
- View detailed call information including transcripts
- Call classification and status tracking
- Export and filtering capabilities

### Campaign Management
- Create and manage calling campaigns
- Add contacts with full details (name, address, city, post code)
- Upload contact lists from CSV/Excel files
- Monitor campaign progress in real-time
- Export campaign results

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Setup Instructions

1. **Clone or download the project files**

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure API Keys** (Optional)
   - The application uses the API keys from your existing configuration
   - You can modify the keys in `app.py` if needed

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Access the application**
   - Open your web browser and go to: `http://localhost:5000`
   - Login with: admin / admin123

## Usage

### First Time Setup
1. Visit `http://localhost:5000`
2. Login with: admin / admin123
3. Start creating campaigns and adding contacts

### Dashboard Features

#### Statistics Overview
- **Total Calls**: Shows the total number of calls made
- **Successful Calls**: Calls that ended successfully
- **Pending Calls**: Calls currently in progress
- **Failed Calls**: Calls that failed or were rejected

#### Call Management
- **View All Calls**: Browse through all your call history
- **Search Calls**: Use the search bar to find specific calls
- **Call Details**: Click the eye icon to view detailed call information
- **Make New Call**: Use the "Make New Call" button to initiate a new call

#### Campaign Management
- **Create Campaigns**: Set up calling campaigns with custom settings
- **Add Contacts**: Add contacts with full details (name, address, etc.)
- **File Upload**: Import contact lists from CSV or Excel files
- **Monitor Progress**: Track campaign progress in real-time
- **Export Results**: Download campaign results as CSV

#### Analytics
- **Call Activity Chart**: Shows call volume over the last 7 days
- **Disposition Chart**: Displays the breakdown of call outcomes

### Contact Management

The system supports adding contacts with full details:

#### Manual Entry
- Add contacts one by one with complete information
- Fields: Title, First Name, Last Name, Address (3 lines), City, Post Code
- Only phone number is required

#### File Upload
- Upload CSV or Excel files with contact information
- Required column: `CONTACT NUMBER`
- Optional columns: `TITLE`, `FIRST NAME`, `LAST NAME`, `ADDRESS 1`, `ADDRESS 2`, `ADDRESS 3`, `CITY`, `POST CODE`

#### Sample CSV Format
```csv
CONTACT NUMBER,TITLE,FIRST NAME,LAST NAME,ADDRESS 1,ADDRESS 2,ADDRESS 3,CITY,POST CODE
+27630243757,Ms,Lorraine,Jackson,52 Sheffield Square,,,London,E3 2BZ
+27734141844,Mrs,Helen,Mayhead,157 Stanley Avenue,,,Portsmouth,PO3 6PW
```

### Call Classifications

The system automatically classifies calls based on their content:

- **SALE**: Successful sales or conversions
- **NI**: Not interested
- **CALLBK**: Call back requested
- **DAIR**: Dead air (no meaningful conversation)
- **A**: Answering machine
- **WN**: Wrong number
- **NP**: No pitch (general conversation)
- **XFER**: Call transferred
- **B**: Busy signal
- **DC**: Disconnected number

## API Endpoints

The application provides the following API endpoints:

- `GET /api/calls` - Get all calls
- `GET /api/call/<call_id>` - Get specific call details
- `POST /api/make-call` - Make a new call
- `GET /api/campaigns` - Get all campaigns
- `POST /api/campaigns` - Create a new campaign
- `POST /api/campaigns/<id>/add-contacts` - Add contacts to campaign
- `POST /api/campaigns/<id>/upload-contacts` - Upload contacts from file

## File Structure

```
Aventus Voice Hub/
├── app.py                          # Main Flask application
├── requirements.txt                # Python dependencies
├── README.md                      # This file
├── sample_contacts.csv            # Sample contact file
├── templates/                     # HTML templates
│   ├── base.html                  # Base template
│   ├── login.html                 # Login page
│   ├── dashboard.html             # Main dashboard
│   ├── campaigns.html             # Campaign management
│   └── campaign_details.html      # Campaign details
├── instance/                      # Database files
│   └── aventus_voice_hub_dashboard.db         # SQLite database
└── *.json                         # Call history data files
```

## Configuration

### Environment Variables
You can set the following environment variables:

- `FLASK_SECRET_KEY`: Secret key for session management
- `VAPI_API_KEY`: Your Aventus Voice Hub API key
- `VAPI_ASSISTANT_ID`: Your Aventus Voice Hub Assistant ID
- `VAPI_PHONE_NUMBER_ID`: Your Aventus Voice Hub Phone Number ID

### Database
The application uses SQLite for user and campaign management. The database file (`aventus_voice_hub_dashboard.db`) will be created automatically on first run.

## Security Features

- Password hashing using Werkzeug
- Session-based authentication
- CSRF protection
- Secure headers
- Input validation

## Troubleshooting

### Common Issues

1. **Port already in use**
   - Change the port in `app.py`: `app.run(debug=True, host='0.0.0.0', port=5001)`

2. **API errors**
   - Check your Aventus Voice Hub API credentials in `app.py`
- Ensure your Aventus Voice Hub account has sufficient credits

3. **Database errors**
   - Delete `instance/aventus_voice_hub_dashboard.db` and restart the application

4. **Import errors**
   - Make sure all dependencies are installed: `pip install -r requirements.txt`

5. **File upload issues**
   - Ensure the CSV/Excel file has the correct column headers
   - Check that phone numbers are in international format (+country code)

### Logs
Check the console output for detailed error messages and API responses.

## Development

### Adding New Features
1. Modify `app.py` for backend logic
2. Update templates in the `templates/` directory
3. Add JavaScript functionality in the template files

### Styling
The application uses Bootstrap 5 and custom CSS. Modify the styles in `templates/base.html` to customize the appearance.

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the console logs for error messages
3. Ensure all dependencies are properly installed

## License

This project is for educational and personal use. Please respect Aventus Voice Hub's terms of service when using their API.

## Changelog

### Version 2.0.0
- Added campaign management system
- Contact management with full details (name, address, etc.)
- CSV and Excel file upload support
- Enhanced phone number validation for international calls
- Improved user interface with tabs and better organization

### Version 1.0.0
- Initial release
- User authentication system
- Call management dashboard
- Real-time statistics and charts
- Call classification and analytics 