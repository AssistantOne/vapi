#!/usr/bin/env python3
"""
Test script to verify call logs endpoint functionality
"""

import requests
import json

def test_call_logs():
    """Test the call logs endpoint for campaign 1"""
    
    # Test URL (assuming Flask is running on localhost:5000)
    base_url = "http://localhost:5000"
    
    # First, try to login (if needed)
    session = requests.Session()
    
    # Test login
    login_data = {
        'username': 'admin',
        'password': 'admin123'
    }
    
    try:
        login_response = session.post(f"{base_url}/login", data=login_data)
        print(f"Login status: {login_response.status_code}")
        
        # Test call logs endpoint for campaign 1
        call_logs_response = session.get(f"{base_url}/api/campaigns/1/call-logs")
        print(f"Call logs status: {call_logs_response.status_code}")
        
        if call_logs_response.status_code == 200:
            call_logs = call_logs_response.json()
            print(f"Found {len(call_logs)} call logs")
            
            if call_logs:
                print("\nFirst call log:")
                print(json.dumps(call_logs[0], indent=2))
            else:
                print("No call logs found")
                
        else:
            print(f"Error: {call_logs_response.text}")
            
        # Test campaign status endpoint
        status_response = session.get(f"{base_url}/api/campaigns/1/status")
        print(f"\nCampaign status: {status_response.status_code}")
        
        if status_response.status_code == 200:
            status_data = status_response.json()
            print("Campaign status data:")
            print(json.dumps(status_data, indent=2))
            
    except requests.exceptions.ConnectionError:
        print("Error: Could not connect to Flask server. Make sure it's running on localhost:5000")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_call_logs() 