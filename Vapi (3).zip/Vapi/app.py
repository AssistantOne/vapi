from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
from datetime import datetime
import requests
from functools import wraps
from openai import OpenAI
import csv
import io
import pandas as pd
from werkzeug.utils import secure_filename
import time
from datetime import timedelta

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///aventus_voice_hub_dashboard.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

db = SQLAlchemy(app)

# Simple cache for call classifications to prevent repeated API calls
classification_cache = {}

def clear_classification_cache():
    """Clear the classification cache to prevent memory issues"""
    global classification_cache
    cache_size = len(classification_cache)
    classification_cache.clear()
    print(f"Cleared classification cache ({cache_size} entries)")

# Aventus Voice Hub API Configuration
API_KEY = "09aaee16-8fb8-4db1-ad0b-b1f1e56a760c"
ASSISTANT_ID = "aa5c886d-6d1c-4c45-844c-a44fdcb7a834"  # tigers milk demo
PHONE_NUMBER_ID = "5c897234-51e7-459f-a685-5239e96438de"  # twilio number
BASE_URL = "https://api.vapi.ai"

# OpenAI API Configuration
OPENAI_API_KEY = "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"

# Add caching variables after the existing imports
_call_cache = {}
_cache_timestamps = {}
CACHE_DURATION = 30  # seconds

def cache_result(duration=CACHE_DURATION):
    """Decorator to cache function results"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            cache_key = f"{func.__name__}:{hash(str(args) + str(kwargs))}"
            current_time = time.time()
            
            # Check if we have cached data and it's still valid
            if cache_key in _call_cache and cache_key in _cache_timestamps:
                if current_time - _cache_timestamps[cache_key] < duration:
                    print(f"📦 Using cached data for {func.__name__}")
                    return _call_cache[cache_key]
            
            # Get fresh data
            result = func(*args, **kwargs)
            
            # Cache the result
            _call_cache[cache_key] = result
            _cache_timestamps[cache_key] = current_time
            
            print(f"💾 Cached fresh data for {func.__name__}")
            return result
        return wrapper
    return decorator

def clear_cache():
    """Clear all cached data"""
    global _call_cache, _cache_timestamps
    _call_cache.clear()
    _cache_timestamps.clear()
    print("🗑️ Cache cleared")

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Campaign Models
class Campaign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(50), default='draft')  # draft, active, paused, completed
    total_numbers = db.Column(db.Integer, default=0)
    called_numbers = db.Column(db.Integer, default=0)
    successful_calls = db.Column(db.Integer, default=0)
    failed_calls = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Campaign settings
    call_delay = db.Column(db.Integer, default=30)  # seconds between calls
    max_concurrent_calls = db.Column(db.Integer, default=1)
    retry_failed_calls = db.Column(db.Boolean, default=True)
    max_retries = db.Column(db.Integer, default=3)
    
    # Relationships
    phone_numbers = db.relationship('CampaignPhoneNumber', backref='campaign', lazy=True, cascade='all, delete-orphan')
    call_logs = db.relationship('CampaignCallLog', backref='campaign', lazy=True, cascade='all, delete-orphan')

class CampaignPhoneNumber(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(20), nullable=False)
    
    # Contact information fields
    title = db.Column(db.String(10))  # Mr, Mrs, Ms, etc.
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    address_1 = db.Column(db.String(200))
    address_2 = db.Column(db.String(200))
    address_3 = db.Column(db.String(200))
    city = db.Column(db.String(100))
    post_code = db.Column(db.String(20))
    
    # Call status fields
    status = db.Column(db.String(50), default='pending')  # pending, calling, completed, failed, retry
    retry_count = db.Column(db.Integer, default=0)
    last_called_at = db.Column(db.DateTime)
    call_id = db.Column(db.String(100))  # Aventus Voice Hub call ID
    disposition = db.Column(db.String(50))
    duration = db.Column(db.Integer, default=0)
    transcript = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign.id'), nullable=False)

class CampaignCallLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign.id'), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    call_id = db.Column(db.String(100))
    status = db.Column(db.String(50))
    disposition = db.Column(db.String(50))
    duration = db.Column(db.Integer, default=0)
    transcript = db.Column(db.Text)
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Create database tables
with app.app_context():
    db.create_all()

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Aventus Voice Hub API Functions
def test_aventus_voice_hub_credentials():
    """Test Aventus Voice Hub API credentials comprehensively"""
    print("🔍 Starting comprehensive Aventus Voice Hub API test...")
    print(f"🔑 API Key: {API_KEY[:10]}...")
    print(f"🤖 Assistant ID: {ASSISTANT_ID}")
    print(f"📱 Phone Number ID: {PHONE_NUMBER_ID}")
    print(f"🌐 Base URL: {BASE_URL}")
    
    # Test 1: Check Assistant
    print("\n📋 Test 1: Checking Assistant...")
    assistant_url = f"{BASE_URL}/assistant/{ASSISTANT_ID}"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(assistant_url, headers=headers, timeout=10)
        print(f"📊 Assistant Response Status: {response.status_code}")
        print(f"📊 Assistant Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            assistant_data = response.json()
            print(f"✅ Assistant found: {assistant_data.get('name', 'Unknown')}")
            print(f"📋 Assistant details: {json.dumps(assistant_data, indent=2)}")
        else:
            print(f"❌ Assistant Error: {response.status_code}")
            print(f"🔍 Error Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Assistant Exception: {e}")
        return False
    
    # Test 2: Check Phone Number
    print("\n📱 Test 2: Checking Phone Number...")
    phone_url = f"{BASE_URL}/phone-number/{PHONE_NUMBER_ID}"
    
    try:
        response = requests.get(phone_url, headers=headers, timeout=10)
        print(f"📊 Phone Response Status: {response.status_code}")
        
        if response.status_code == 200:
            phone_data = response.json()
            print(f"✅ Phone Number found: {phone_data.get('phoneNumber', 'Unknown')}")
            print(f"📋 Phone details: {json.dumps(phone_data, indent=2)}")
        else:
            print(f"❌ Phone Number Error: {response.status_code}")
            print(f"🔍 Error Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Phone Number Exception: {e}")
        return False
    
    # Test 3: Check Account Balance/Credits
    print("\n💰 Test 3: Checking Account...")
    account_url = f"{BASE_URL}/account"
    
    try:
        response = requests.get(account_url, headers=headers, timeout=10)
        print(f"📊 Account Response Status: {response.status_code}")
        
        if response.status_code == 200:
            account_data = response.json()
            print(f"✅ Account info retrieved")
            print(f"📋 Account details: {json.dumps(account_data, indent=2)}")
        else:
            print(f"⚠️ Account check failed: {response.status_code}")
            print(f"🔍 Response: {response.text}")
    except Exception as e:
        print(f"⚠️ Account check exception: {e}")
    
    # Test 4: Test Call Creation (without actually making a call)
    print("\n📞 Test 4: Testing Call Creation (dry run)...")
    call_url = f"{BASE_URL}/call"
    
    # Create a test payload
    test_payload = {
        "assistantId": ASSISTANT_ID,
        "phoneNumberId": PHONE_NUMBER_ID,
        "customer": {
            "number": "+1234567890"  # Test number
        }
    }
    
    print(f"📋 Test Payload: {json.dumps(test_payload, indent=2)}")
    
    try:
        # Just test the endpoint structure, don't actually create a call
        response = requests.post(call_url, json=test_payload, headers=headers, timeout=10)
        print(f"📊 Call Test Response Status: {response.status_code}")
        
        if response.status_code in [200, 201, 400, 422]:  # Valid responses
            print(f"✅ Call endpoint is accessible")
            if response.status_code in [400, 422]:
                error_data = response.json()
                print(f"📋 Expected validation error: {json.dumps(error_data, indent=2)}")
        else:
            print(f"❌ Call endpoint error: {response.status_code}")
            print(f"🔍 Error Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Call endpoint exception: {e}")
        return False
    
    print("\n✅ All Aventus Voice Hub API tests completed successfully!")
    return True

def get_all_calls():
    """Get all calls from Aventus Voice Hub API with fallback to sample data"""
    try:
        # Try to get real data from Aventus Voice Hub API first
        url = f"{BASE_URL}/call"
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            calls = response.json()
            print(f"✅ Retrieved {len(calls)} calls from Aventus Voice Hub API")
            return calls
        else:
            print(f"⚠️ Aventus Voice Hub API returned {response.status_code}, using sample data")
            return get_sample_calls()
            
    except Exception as e:
        print(f"⚠️ Error fetching from Aventus Voice Hub API: {e}, using sample data")
        return get_sample_calls()

def get_sample_calls():
    """Get sample calls from the JSON file"""
    try:
        with open('vapi_call_history_with_openai_classification.json', 'r') as f:
            data = json.load(f)
            calls = data.get('call_summary', [])
            return calls
    except FileNotFoundError:
        print("Error: Sample data file not found")
        return []
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in sample data file: {e}")
        return []
    except Exception as e:
        print(f"Error loading sample data: {e}")
        return []

def get_call_details(call_id):
    """Get detailed information about a specific call"""
    url = f"{BASE_URL}/call/{call_id}"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error retrieving call details for {call_id}: {e}")
        return None

def make_single_call(phone_number):
    """Make a single outbound call using Aventus Voice Hub API"""
    url = f"{BASE_URL}/call"
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Build payload without context (Aventus Voice Hub API doesn't support context field)
    payload = {
        "assistantId": ASSISTANT_ID,
        "phoneNumberId": PHONE_NUMBER_ID,
        "customer": {
            "number": phone_number
        },
        "maxDurationSeconds": 300  # 5 minutes max
    }
    
    # Note: Campaign context removed as Aventus Voice Hub API doesn't support context field
    # Campaign information can be tracked in the local database instead
    
    print(f"🚀 Making outbound call to {phone_number}...")
    print(f"📞 Aventus Voice Hub API URL: {url}")
    print(f"🔑 Using Assistant ID: {ASSISTANT_ID}")
    print(f"📱 Using Phone Number ID: {PHONE_NUMBER_ID}")
    print(f"📋 Payload: {json.dumps(payload, indent=2)}")
    
    try:
        print("📡 Sending request to Aventus Voice Hub API...")
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        
        print(f"📊 Response Status Code: {response.status_code}")
        print(f"📊 Response Headers: {dict(response.headers)}")
        
        if response.status_code in [200, 201]:  # 200 OK or 201 Created
            result = response.json()
            print(f"✅ Call initiated successfully!")
            print(f"📊 Response: {json.dumps(result, indent=2)}")
            return result
        else:
            print(f"❌ API Error: {response.status_code}")
            print(f"🔍 Response text: {response.text}")
            
            # Try to parse error response
            try:
                error_data = response.json()
                error_message = error_data.get('message', 'Unknown error')
                print(f"🔍 Error message: {error_message}")
            except:
                print(f"🔍 Raw error response: {response.text}")
            
            return None
            
    except requests.exceptions.Timeout:
        print(f"❌ Timeout error making call to {phone_number}")
        return None
    except requests.exceptions.ConnectionError as e:
        print(f"❌ Connection error making call to {phone_number}: {e}")
        return None
    except requests.exceptions.RequestException as e:
        print(f"❌ Request error making call to {phone_number}: {e}")
        return None
    except Exception as e:
        print(f"❌ Unexpected error making call to {phone_number}: {e}")
        return None



# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

# Registration disabled - only admin user allowed
@app.route('/register', methods=['GET', 'POST'])
def register():
    flash('Registration is disabled. Use admin/admin123 to login.', 'info')
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Simple admin authentication - only one user
        if username == 'admin' and password == 'admin123':
            session['user_id'] = 1
            session['username'] = 'admin'
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password! Use: admin / admin123', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard_professional.html')

@app.route('/make-call')
@login_required
def make_call():
    return render_template('make_call.html')

@app.route('/campaigns')
@login_required
def campaigns():
    return render_template('campaigns.html')

@app.route('/campaigns/<int:campaign_id>')
@login_required
def campaign_details(campaign_id):
    return render_template('campaign_details_professional.html', campaign_id=campaign_id)

@cache_result(duration=15)  # Cache for 15 seconds
def get_cached_calls(limit=10):
    """Get cached calls data with limit"""
    try:
        calls = get_all_calls()
        calls = calls[:limit]
        
        # Process calls to add classification
        processed_calls = []
        for i, call in enumerate(calls):
            try:
                # Handle both API response format and sample data format
                call_id = call.get('id') or call.get('call_id', 'Unknown')
                customer_number = call.get('customer', {}).get('number') or call.get('customer_number', 'Unknown')
                status = call.get('status', 'Unknown')
                created_at = call.get('createdAt') or call.get('created_at', 'Unknown')
                transcript = call.get('transcript', 'No transcript available')
                
                # Ensure duration is properly converted to integer
                duration = call.get('duration', 0)
                
                if isinstance(duration, str):
                    try:
                        duration = int(duration)
                    except (ValueError, TypeError):
                        duration = 0
                elif not isinstance(duration, (int, float)):
                    duration = 0
                
                # Use existing disposition if available, otherwise classify
                disposition = call.get('disposition')
                if not disposition:
                    try:
                        # Only classify if transcript is meaningful
                        if transcript and transcript != "No transcript available" and len(transcript.strip()) > 10:
                            disposition = classify_call(transcript, customer_number)
                        else:
                            disposition = "DAIR"  # Dead Air for short/no transcripts
                    except Exception as classify_error:
                        print(f"Classification failed for call {call_id}: {classify_error}")
                        disposition = "UNKNOWN"
                
                # Clean up phone number - replace "Unknown" with a more user-friendly message
                phone_number = customer_number if customer_number != 'Unknown' else 'Private Number'
                
                call_data = {
                    'id': call_id,
                    'phone_number': phone_number,
                    'status': status,
                    'created_at': created_at,
                    'transcript': transcript,
                    'duration': duration,
                    'disposition': disposition
                }
                
                processed_calls.append(call_data)
                
                # Clear cache every 50 calls to prevent memory issues
                if (i + 1) % 50 == 0:
                    clear_classification_cache()
                    
            except Exception as call_error:
                print(f"Error processing individual call: {call_error}")
                continue
        
        return processed_calls
    except Exception as e:
        print(f"❌ Error in get_cached_calls: {e}")
        return []

@app.route('/api/calls')
@login_required
def api_calls():
    """API endpoint to get all calls"""
    print("📞 API: /api/calls endpoint called")
    
    # Get limit parameter from request, default to 10
    limit = request.args.get('limit', default=10, type=int)
    print(f"📊 Requested limit: {limit}")
    
    try:
        processed_calls = get_cached_calls(limit)
        print(f"✅ Processed {len(processed_calls)} calls for API response")
        return jsonify(processed_calls)
    except Exception as e:
        print(f"❌ Error in /api/calls endpoint: {e}")
        # Return empty array instead of error to prevent frontend crashes
        return jsonify([])

@app.route('/api/call/<call_id>')
@login_required
def api_call_details(call_id):
    """API endpoint to get specific call details"""
    # First try to get from API
    call_details = get_call_details(call_id)
    
    # If not found in API, try to find in sample data
    if not call_details:
        call_details = get_call_details_from_sample(call_id)
    
    if call_details:
        # Use existing disposition if available, otherwise classify
        if not call_details.get('disposition'):
            call_details['disposition'] = classify_call(call_details.get('transcript', ''), call_details.get('customer_number'))
    return jsonify(call_details)

@cache_result(duration=30)  # Cache for 30 seconds
def get_cached_statistics():
    """Get cached statistics data"""
    try:
        # Use processed calls that include disposition classifications
        calls = get_cached_calls(100)  # Get all calls with classifications
        
        total_calls = len(calls)
        
        # Better disposition mapping for success/failure
        # Successful calls: SALE, HO (Home Owner), PR (Private Renting), A (Answering Machine - considered successful contact)
        successful_calls = len([c for c in calls if c.get('disposition') in ['SALE', 'HO', 'PR', 'A']])
        
        # Failed calls: NP (No Pitch), DEC (Declined), DAIR (Dead Air), DC (Disconnected), WN (Wrong Number)
        failed_calls = len([c for c in calls if c.get('disposition') in ['NP', 'DEC', 'DAIR', 'DC', 'WN']])
        
        # Neutral calls: N (No Answer), B (Busy), CALLBK (Call Back), NI (Not Interested), CHU (Customer Hung Up)
        neutral_calls = len([c for c in calls if c.get('disposition') in ['N', 'B', 'CALLBK', 'NI', 'CHU', 'DNQ', 'SL', 'XFER', 'DNC']])
        
        # Debug: Print disposition breakdown
        disposition_counts = {}
        for call in calls:
            disp = call.get('disposition', 'Unknown')
            disposition_counts[disp] = disposition_counts.get(disp, 0) + 1
        
        print(f"📊 Disposition breakdown: {disposition_counts}")
        print(f"📊 Successful dispositions found: {[c.get('disposition') for c in calls if c.get('disposition') in ['SALE', 'HO', 'PR', 'A']]}")
        
        total_duration = sum(c.get('duration', 0) for c in calls)
        success_rate = round((successful_calls / total_calls * 100) if total_calls > 0 else 0, 1)
        avg_duration = round(total_duration / total_calls, 1) if total_calls > 0 else 0
        
        # Calculate unique phone numbers
        unique_numbers = len(set([c.get('customer_number') for c in calls if c.get('customer_number')]))
        
        # Calculate peak hour
        hour_counts = {}
        for call in calls:
            if call.get('created_at'):
                try:
                    if isinstance(call['created_at'], str):
                        if call['created_at'].endswith('Z'):
                            hour = datetime.fromisoformat(call['created_at'].replace('Z', '+00:00')).hour
                        else:
                            hour = datetime.fromisoformat(call['created_at']).hour
                    else:
                        hour = call['created_at'].hour
                    hour_counts[hour] = hour_counts.get(hour, 0) + 1
                except:
                    continue
        
        peak_hour = max(hour_counts.items(), key=lambda x: x[1])[0] if hour_counts else 14
        peak_hour_str = f"{peak_hour:02d}:00"
        
        # Calculate best day
        day_counts = {}
        for call in calls:
            if call.get('created_at'):
                try:
                    if isinstance(call['created_at'], str):
                        if call['created_at'].endswith('Z'):
                            day = datetime.fromisoformat(call['created_at'].replace('Z', '+00:00')).strftime('%a')
                        else:
                            day = datetime.fromisoformat(call['created_at']).strftime('%a')
                    else:
                        day = call['created_at'].strftime('%a')
                    day_counts[day] = day_counts.get(day, 0) + 1
                except:
                    continue
        
        best_day = max(day_counts.items(), key=lambda x: x[1])[0] if day_counts else 'Mon'
        
        # Calculate conversion rate (sales made)
        sales_made = len([c for c in calls if c.get('disposition') == 'SALE'])
        conversion_rate = round((sales_made / total_calls * 100) if total_calls > 0 else 0, 1)
        
        # Calculate retry rate (calls that need follow-up)
        retry_calls = len([c for c in calls if c.get('disposition') in ['CALLBK', 'NI', 'N', 'B']])
        retry_rate = round((retry_calls / total_calls * 100) if total_calls > 0 else 0, 1)
        
        # Calculate week-over-week changes (mock data for now)
        total_calls_change = 5  # +5%
        successful_calls_change = 3  # +3%
        success_rate_change = 5  # +5%
        avg_duration_change = 15  # +15%
        
        stats = {
            'total_calls': total_calls,
            'successful_calls': successful_calls,
            'failed_calls': failed_calls,
            'neutral_calls': neutral_calls,
            'success_rate': success_rate,
            'avg_duration': avg_duration,
            'total_duration': total_duration,
            'unique_numbers': unique_numbers,
            'peak_hour': peak_hour_str,
            'best_day': best_day,
            'conversion_rate': conversion_rate,
            'retry_rate': retry_rate,
            'sales_made': sales_made,
            'changes': {
                'total_calls': total_calls_change,
                'successful_calls': successful_calls_change,
                'success_rate': success_rate_change,
                'avg_duration': avg_duration_change
            }
        }
        
        print(f"📊 Statistics calculated: {total_calls} total calls, {successful_calls} successful, {success_rate}% success rate")
        
        return stats
    except Exception as e:
        print(f"Error getting statistics: {e}")
        # Return default values instead of error to prevent frontend crashes
        return {
            'total_calls': 0,
            'successful_calls': 0,
            'failed_calls': 0,
            'neutral_calls': 0,
            'success_rate': 0,
            'avg_duration': 0,
            'total_duration': 0,
            'unique_numbers': 0,
            'peak_hour': '14:00',
            'best_day': 'Mon',
            'conversion_rate': 0,
            'retry_rate': 0,
            'sales_made': 0,
            'changes': {
                'total_calls': 0,
                'successful_calls': 0,
                'success_rate': 0,
                'avg_duration': 0
            }
        }

@app.route('/api/statistics')
@login_required
def api_statistics():
    """API endpoint to get comprehensive call statistics"""
    try:
        stats = get_cached_statistics()
        return jsonify(stats)
    except Exception as e:
        print(f"Error in api_statistics: {e}")
        return jsonify({
            'total_calls': 0,
            'successful_calls': 0,
            'failed_calls': 0,
            'success_rate': 0,
            'avg_duration': 0,
            'total_duration': 0,
            'unique_numbers': 0,
            'peak_hour': '14:00',
            'best_day': 'Mon',
            'conversion_rate': 0,
            'retry_rate': 0
        })

@cache_result(duration=20)  # Cache for 20 seconds
def get_cached_charts(days=7):
    """Get cached chart data"""
    try:
        # Use processed calls that include disposition classifications
        calls = get_cached_calls(100)  # Get all calls with classifications
        
        # Call activity for specified days
        call_activity = get_call_activity_data(calls, days=days)
        
        # Disposition data
        disposition_data = get_disposition_data(calls)
        
        result = {
            'call_activity': call_activity,
            'dispositions': disposition_data
        }
        return result
    except Exception as e:
        print(f"❌ Error getting chart data: {e}")
        # Return empty chart data instead of error to prevent frontend crashes
        return {
            'call_activity': {'labels': [], 'data': []},
            'dispositions': {'answered': 0, 'no_answer': 0, 'failed': 0, 'other': 0}
        }

@app.route('/api/charts')
@login_required
def api_charts():
    """API endpoint to get chart data"""
    try:
        days = request.args.get('days', 7, type=int)
        result = get_cached_charts(days)
        return jsonify(result)
    except Exception as e:
        print(f"❌ Error in api_charts: {e}")
        return jsonify({
            'call_activity': {'labels': [], 'data': []},
            'dispositions': {'answered': 0, 'no_answer': 0, 'failed': 0, 'other': 0}
        })

@cache_result(duration=10)  # Cache for 10 seconds
def get_recent_activity():
    """Get recent activity data including calls, campaigns, and system events"""
    try:
        # Get recent calls (increase limit to show more calls)
        calls = get_cached_calls(15)
        print(f"📞 Recent activity: Found {len(calls)} recent calls")
        
        # Get recent campaigns
        campaigns = Campaign.query.filter_by(user_id=session['user_id']).order_by(Campaign.updated_at.desc()).limit(3).all()
        print(f"📞 Recent activity: Found {len(campaigns)} recent campaigns")
        
        # Get recent call logs from campaigns
        recent_call_logs = CampaignCallLog.query.join(Campaign).filter(
            Campaign.user_id == session['user_id']
        ).order_by(CampaignCallLog.created_at.desc()).limit(5).all()
        print(f"📞 Recent activity: Found {len(recent_call_logs)} recent call logs")
        
        activity_items = []
        
        # Add recent calls with better formatting
        for call in calls:
            # Format duration
            duration = call.get('duration', 0)
            duration_str = f"{duration}s" if duration > 0 else "0s"
            
            # Format disposition
            disposition = call.get('disposition', 'Unknown')
            disposition_str = disposition if disposition != 'Unknown' else 'No disposition'
            
            # Debug: Print call details
            print(f"📞 Adding call activity: {call['phone_number']} - {disposition}")
            
            activity_items.append({
                'type': 'call',
                'id': call['id'],
                'title': f"Call to {call['phone_number']}",
                'description': f"Status: {call['status']} • Duration: {duration_str} • Disposition: {disposition_str}",
                'disposition': disposition,
                'timestamp': call['created_at'],
                'icon': 'fas fa-phone',
                'status': call['status']
            })
        
        # Add recent campaign activities
        for campaign in campaigns:
            activity_items.append({
                'type': 'campaign',
                'id': campaign.id,
                'title': f"Campaign: {campaign.name}",
                'description': f"Status: {campaign.status} • {campaign.called_numbers}/{campaign.total_numbers} calls",
                'timestamp': campaign.updated_at.isoformat(),
                'icon': 'fas fa-bullhorn',
                'status': campaign.status
            })
        
        # Add recent call logs
        for log in recent_call_logs:
            activity_items.append({
                'type': 'call_log',
                'id': log.id,
                'title': f"Campaign call to {log.phone_number}",
                'description': f"Disposition: {log.disposition or 'Unknown'} • Duration: {log.duration}s",
                'disposition': log.disposition,
                'timestamp': log.created_at.isoformat(),
                'icon': 'fas fa-phone-alt',
                'status': log.status
            })
        
        # Sort by timestamp (most recent first)
        activity_items.sort(key=lambda x: x['timestamp'], reverse=True)
        
        # Limit to 15 most recent activities (increased from 10)
        result = activity_items[:15]
        print(f"📞 Recent activity: Returning {len(result)} activities")
        
        # Debug: Print first few activities
        for i, activity in enumerate(result[:3]):
            print(f"📞 Activity {i+1}: {activity['title']} - {activity['disposition']}")
        
        return result
        
    except Exception as e:
        print(f"Error getting recent activity: {e}")
        return []

@app.route('/api/recent-activity')
@login_required
def api_recent_activity():
    """API endpoint to get recent activity"""
    try:
        print("📞 Recent activity API endpoint called")
        activity = get_recent_activity()
        print(f"📞 Recent activity API returning {len(activity)} items")
        return jsonify(activity)
    except Exception as e:
        print(f"Error in api_recent_activity: {e}")
        return jsonify([])

@app.route('/api/test-recent-activity')
@login_required
def test_recent_activity():
    """Test endpoint for recent activity"""
    try:
        print("🧪 Test recent activity endpoint called")
        return jsonify({
            "status": "success",
            "message": "Recent activity endpoint is working",
            "timestamp": datetime.utcnow().isoformat()
        })
    except Exception as e:
        print(f"Error in test recent activity: {e}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/clear-cache', methods=['POST'])
@login_required
def api_clear_cache():
    """API endpoint to clear cache"""
    try:
        clear_cache()
        print("🧹 Cache cleared successfully")
        return jsonify({'message': 'Cache cleared successfully'})
    except Exception as e:
        print(f"Error clearing cache: {e}")
        return jsonify({'error': 'Failed to clear cache'}), 500

def get_call_activity_data(calls, days=7):
    """Generate call activity data for the specified number of days"""
    from datetime import datetime, timedelta
    
    # Get dates for the specified period
    today = datetime.now()
    dates = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(days-1, -1, -1)]
    
    # Count calls per day
    call_counts = {}
    for call in calls:
        created_at = call.get('createdAt') or call.get('created_at')
        if created_at and created_at != 'Unknown':
            try:
                # Parse date and get just the date part
                if isinstance(created_at, str):
                    # Handle ISO format with Z timezone
                    if created_at.endswith('Z'):
                        call_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d')
                    else:
                        call_date = datetime.fromisoformat(created_at).strftime('%Y-%m-%d')
                else:
                    call_date = created_at.strftime('%Y-%m-%d')
                
                call_counts[call_date] = call_counts.get(call_date, 0) + 1
            except Exception as e:
                print(f"Error parsing date {created_at}: {e}")
                continue
    
    # Format labels based on period
    if days <= 7:
        labels = [datetime.strptime(d, '%Y-%m-%d').strftime('%b %d') for d in dates]
    elif days <= 30:
        labels = [datetime.strptime(d, '%Y-%m-%d').strftime('%b %d') for d in dates]
    else:
        # For 90 days, show weekly labels
        labels = []
        for i, d in enumerate(dates):
            if i % 7 == 0 or i == len(dates) - 1:  # Show every 7th day and last day
                labels.append(datetime.strptime(d, '%Y-%m-%d').strftime('%b %d'))
            else:
                labels.append('')
    
    return {
        'labels': labels,
        'data': [call_counts.get(d, 0) for d in dates]
    }

def get_disposition_data(calls):
    """Generate comprehensive disposition data for charts"""
    disposition_counts = {
        'answered': 0,
        'no_answer': 0,
        'failed': 0,
        'other': 0
    }
    
    for call in calls:
        disposition = call.get('disposition')
        if not disposition:
            try:
                disposition = classify_call(call.get('transcript', ''), call.get('customer_number'))
            except Exception as e:
                print(f"Classification failed for disposition: {e}")
                disposition = "UNKNOWN"
        
        # Categorize dispositions
        if disposition in ['A', 'PR']:
            disposition_counts['answered'] += 1
        elif disposition in ['NP', 'DAIR']:
            disposition_counts['no_answer'] += 1
        elif disposition in ['DEC', 'HO']:
            disposition_counts['failed'] += 1
        else:
            disposition_counts['other'] += 1
    
    return disposition_counts

def get_call_details_from_sample(call_id):
    """Get call details from sample data"""
    try:
        with open('vapi_call_history_with_openai_classification.json', 'r') as f:
            data = json.load(f)
            calls = data.get('call_summary', [])
            for call in calls:
                if call.get('call_id') == call_id:
                    return call
        return None
    except Exception as e:
        print(f"Error loading sample call details: {e}")
        return None

@app.route('/api/test-credentials')
@login_required
def api_test_credentials():
    """API endpoint to test Aventus Voice Hub credentials"""
    try:
        is_valid = test_aventus_voice_hub_credentials()
        return jsonify({
            'valid': is_valid,
            'message': 'Aventus Voice Hub API credentials are valid!' if is_valid else 'Aventus Voice Hub API credentials are invalid. Please check your configuration.'
        })
    except Exception as e:
        return jsonify({
            'valid': False,
            'message': f'Error testing credentials: {str(e)}'
        })

@app.route('/api/make-call', methods=['POST'])
@login_required
def api_make_call():
    """API endpoint to make a new call"""
    print("📞 API: Make call request received")
    data = request.get_json()
    phone_number = data.get('phone_number')
    demo_mode = data.get('demo_mode', False)
    
    print(f"📱 Raw phone number: {phone_number}")
    print(f"🎭 Demo mode: {demo_mode}")
    
    if not phone_number:
        print("❌ Error: Phone number is required")
        return jsonify({'error': 'Phone number is required'}), 400
    
    if demo_mode:
        # Simulate a successful call for demo purposes
        import uuid
        import time
        call_id = str(uuid.uuid4())
        print(f"🎭 Demo mode: Simulating successful call with ID: {call_id}")
        
        # Create a mock call result
        mock_result = {
            'id': call_id,
            'status': 'initiated',
            'phone_number': phone_number,
            'created_at': datetime.utcnow().isoformat(),
            'demo': True
        }
        
        return jsonify({
            'success': True, 
            'call': mock_result,
            'message': 'Demo call initiated successfully!'
        })
    
    print("🚀 Initiating real call via Aventus Voice Hub API...")
    
    # Clean phone number (remove spaces, dashes, parentheses)
    cleaned_phone = ''.join(filter(str.isdigit, phone_number))
    
    # Add + if not present
    if not cleaned_phone.startswith('+'):
        cleaned_phone = '+' + cleaned_phone
    
    # Validate phone number format
    if not cleaned_phone.startswith('+'):
        return jsonify({'error': 'Phone number must start with + and include country code (e.g., +27630243757 for South Africa)'}), 400
    
    # Check for valid international phone number format (10-15 digits including country code)
    digits_only = cleaned_phone[1:]  # Remove the + sign
    if len(digits_only) < 10 or len(digits_only) > 15:
        return jsonify({'error': 'Please use a valid international phone number format (10-15 digits including country code)'}), 400
    
    # Use the cleaned phone number for the API call
    phone_number = cleaned_phone
    
    print(f"📱 Original phone number: {data.get('phone_number')}")
    print(f"📱 Cleaned phone number: {cleaned_phone}")
    print(f"📱 Digits only: {digits_only}")
    print(f"📱 Length: {len(digits_only)}")
    
    # Test credentials first
    print("🔍 Testing credentials before making call...")
    if not test_aventus_voice_hub_credentials():
        return jsonify({
            'error': 'Aventus Voice Hub API credentials test failed. Please check:\n' +
                     '• API Key is valid\n' +
                     '• Assistant ID exists\n' +
                     '• Phone Number ID exists\n' +
                     '• You have sufficient credits'
        }), 500
    
    print("✅ Credentials test passed, making call...")
    result = make_single_call(phone_number)
    
    if result:
        print(f"✅ Call initiated successfully! Call ID: {result.get('id', 'Unknown')}")
        return jsonify({'success': True, 'call': result})
    else:
        print("❌ Failed to make call")
        return jsonify({
            'error': 'Failed to make call. This could be due to:\n' +
                     '• Invalid phone number format\n' +
                     '• Insufficient Aventus Voice Hub credits\n' +
                     '• Network connectivity issues\n' +
                     '• Aventus Voice Hub API service issues\n\n' +
                     'Please try again or contact support if the issue persists.'
        }), 500

@app.route('/api/call-status/<call_id>')
@login_required
def api_call_status(call_id):
    """API endpoint to get call status with AI classification"""
    try:
        # Get call details from Aventus Voice Hub API
        url = f"{BASE_URL}/call/{call_id}"
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            call_data = response.json()
            transcript = call_data.get('transcript', '')
            phone_number = call_data.get('customer', {}).get('number', 'Unknown')
            original_disposition = call_data.get('disposition', 'Unknown')
            
            # Calculate duration from start and end times
            duration = 0
            if call_data.get('startedAt') and call_data.get('endedAt'):
                try:
                    from datetime import datetime
                    start_time = datetime.fromisoformat(call_data['startedAt'].replace('Z', '+00:00'))
                    end_time = datetime.fromisoformat(call_data['endedAt'].replace('Z', '+00:00'))
                    duration = int((end_time - start_time).total_seconds())
                except Exception as e:
                    print(f"Error calculating duration: {e}")
                    duration = call_data.get('duration', 0)
            else:
                duration = call_data.get('duration', 0)
            
            # Initialize response data
            response_data = {
                'status': call_data.get('status', 'unknown'),
                'phone_number': phone_number,
                'duration': duration,
                'original_disposition': original_disposition,
                'transcript': transcript,
                'cost': call_data.get('cost', 0),
                'call_id': call_id,
                'ai_classification': {
                    'disposition': None,
                    'method': None,
                    'available': False
                }
            }
            
            # Check if we have a transcript to classify
            if transcript and transcript != "No transcript available":
                try:
                    # Classify the transcript using OpenAI
                    print(f"🔍 Classifying call {call_id} for {phone_number}")
                    ai_disposition = classify_call(transcript, phone_number)
                    
                    response_data['ai_classification'] = {
                        'disposition': ai_disposition,
                        'method': 'OpenAI',
                        'available': True
                    }
                    
                    print(f"✅ Call {call_id} classified as: {ai_disposition}")
                    
                except Exception as e:
                    print(f"❌ Error classifying call {call_id}: {e}")
                    response_data['ai_classification'] = {
                        'disposition': 'UNKNOWN',
                        'method': 'Error',
                        'available': False,
                        'error': str(e)
                    }
            else:
                # No transcript available
                response_data['ai_classification'] = {
                    'disposition': 'DAIR',
                    'method': 'Rule-based (no transcript)',
                    'available': False,
                    'message': 'No transcript available for classification'
                }
            
            return jsonify(response_data)
        else:
            return jsonify({'error': 'Call not found'}), 404
    except Exception as e:
        print(f"Error getting call status: {e}")
        return jsonify({'error': 'Failed to get call status'}), 500

@app.route('/api/call-transcript/<call_id>')
@login_required
def api_call_transcript(call_id):
    """API endpoint to get call transcript"""
    try:
        # First try to get from Vapi API directly
        url = f"{BASE_URL}/call/{call_id}"
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            call_data = response.json()
            transcript = call_data.get('transcript', '')
            
            if transcript and transcript != "No transcript available":
                return jsonify({
                    'transcript': transcript,
                    'call_id': call_id,
                    'phone_number': call_data.get('customer', {}).get('number', 'Unknown'),
                    'duration': call_data.get('duration', 0),
                    'created_at': call_data.get('created_at', 'Unknown'),
                    'disposition': call_data.get('disposition', 'Unknown'),
                    'source': 'Vapi API',
                    'status': call_data.get('status', 'Unknown'),
                    'cost': call_data.get('cost', 0)
                })
        
        # Fallback to local database
        call_details = get_call_details(call_id)
        
        # If not found in API, try to find in sample data
        if not call_details:
            call_details = get_call_details_from_sample(call_id)
        
        if call_details and call_details.get('transcript'):
            return jsonify({
                'transcript': call_details['transcript'],
                'call_id': call_id,
                'phone_number': call_details.get('customer_number', 'Unknown'),
                'duration': call_details.get('duration', 0),
                'created_at': call_details.get('created_at', 'Unknown'),
                'disposition': call_details.get('disposition', 'Unknown'),
                'source': 'Local Database'
            })
        else:
            return jsonify({'error': 'Transcript not found'}), 404
            
    except Exception as e:
        print(f"Error getting transcript: {e}")
        return jsonify({'error': 'Failed to get transcript'}), 500

@app.route('/api/classify-transcript', methods=['POST'])
@login_required
def api_classify_transcript():
    """API endpoint to classify a transcript using OpenAI"""
    try:
        data = request.get_json()
        transcript = data.get('transcript', '')
        phone_number = data.get('phone_number', '')
        call_id = data.get('call_id', '')
        
        if not transcript:
            return jsonify({'error': 'Transcript is required'}), 400
        
        # Classify the transcript using OpenAI
        print(f"🔍 Classifying transcript for {phone_number or call_id}")
        disposition = classify_call(transcript, phone_number)
        
        return jsonify({
            'success': True,
            'disposition': disposition,
            'transcript': transcript,
            'phone_number': phone_number,
            'call_id': call_id,
            'classification_method': 'OpenAI'
        })
        
    except Exception as e:
        print(f"Error classifying transcript: {e}")
        return jsonify({'error': 'Failed to classify transcript'}), 500

@app.route('/api/classify-call/<call_id>', methods=['POST'])
@login_required
def api_classify_call(call_id):
    """API endpoint to get call transcript and classify it"""
    try:
        # Get call details from Aventus Voice Hub API
        url = f"{BASE_URL}/call/{call_id}"
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            call_data = response.json()
            transcript = call_data.get('transcript', '')
            phone_number = call_data.get('customer', {}).get('number', 'Unknown')
            duration = call_data.get('duration', 0)
            original_disposition = call_data.get('disposition', 'Unknown')
            
            if transcript and transcript != "No transcript available":
                # Classify the transcript using OpenAI
                print(f"🔍 Classifying call {call_id} for {phone_number}")
                ai_disposition = classify_call(transcript, phone_number)
                
                return jsonify({
                    'success': True,
                    'call_id': call_id,
                    'phone_number': phone_number,
                    'transcript': transcript,
                    'duration': duration,
                    'original_disposition': original_disposition,
                    'ai_disposition': ai_disposition,
                    'classification_method': 'OpenAI'
                })
            else:
                return jsonify({
                    'success': False,
                    'call_id': call_id,
                    'phone_number': phone_number,
                    'transcript': transcript,
                    'duration': duration,
                    'original_disposition': original_disposition,
                    'ai_disposition': 'DAIR',  # Dead Air - no transcript
                    'classification_method': 'Rule-based (no transcript)',
                    'message': 'No transcript available for classification'
                })
        else:
            return jsonify({'error': 'Call not found'}), 404
            
    except Exception as e:
        print(f"Error classifying call: {e}")
        return jsonify({'error': 'Failed to classify call'}), 500

@app.route('/api/cancel-call/<call_id>', methods=['POST'])
@login_required
def api_cancel_call(call_id):
    """API endpoint to cancel a call"""
    try:
        # Cancel call via Aventus Voice Hub API
        url = f"{BASE_URL}/call/{call_id}/cancel"
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.post(url, headers=headers)
        if response.status_code == 200:
            return jsonify({'success': True, 'message': 'Call cancelled successfully'})
        else:
            return jsonify({'error': 'Failed to cancel call'}), 400
    except Exception as e:
        print(f"Error cancelling call: {e}")
        return jsonify({'error': 'Failed to cancel call'}), 500

# Campaign API Endpoints
@app.route('/api/campaigns', methods=['GET'])
@login_required
def api_campaigns():
    """Get all campaigns for the current user"""
    try:
        campaigns = Campaign.query.filter_by(user_id=session['user_id']).order_by(Campaign.created_at.desc()).all()
        campaign_list = []
        
        for campaign in campaigns:
            campaign_data = {
                'id': campaign.id,
                'name': campaign.name,
                'description': campaign.description,
                'status': campaign.status,
                'total_numbers': campaign.total_numbers,
                'called_numbers': campaign.called_numbers,
                'successful_calls': campaign.successful_calls,
                'failed_calls': campaign.failed_calls,
                'created_at': campaign.created_at.isoformat(),
                'updated_at': campaign.updated_at.isoformat(),
                'call_delay': campaign.call_delay,
                'max_concurrent_calls': campaign.max_concurrent_calls,
                'retry_failed_calls': campaign.retry_failed_calls,
                'max_retries': campaign.max_retries
            }
            campaign_list.append(campaign_data)
        
        return jsonify(campaign_list)
    except Exception as e:
        print(f"Error fetching campaigns: {e}")
        return jsonify({'error': 'Failed to fetch campaigns'}), 500

@app.route('/api/campaigns', methods=['POST'])
@login_required
def api_create_campaign():
    """Create a new campaign"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name'):
            return jsonify({'error': 'Campaign name is required'}), 400
        
        # Create campaign
        campaign = Campaign(
            name=data['name'],
            description=data.get('description', ''),
                    call_delay=max(1, min(300, data.get('call_delay', 30))),  # 1-300 seconds
        max_concurrent_calls=max(1, min(10, data.get('max_concurrent_calls', 1))),  # 1-10 calls
        retry_failed_calls=data.get('retry_failed_calls', True),
        max_retries=max(0, min(5, data.get('max_retries', 3))),  # 0-5 retries
            user_id=session['user_id']
        )
        
        # Store demo mode preference in campaign description if needed
        if data.get('demo_mode', False):
            if campaign.description:
                campaign.description += " [DEMO MODE]"
            else:
                campaign.description = "[DEMO MODE]"
        
        db.session.add(campaign)
        db.session.commit()
        
        # Add phone numbers if provided
        if data.get('phone_numbers'):
            phone_numbers = data['phone_numbers']
            for phone_number in phone_numbers:
                if phone_number.strip():
                    campaign_phone = CampaignPhoneNumber(
                        phone_number=phone_number.strip(),
                        campaign_id=campaign.id
                    )
                    db.session.add(campaign_phone)
            
            campaign.total_numbers = len([p for p in phone_numbers if p.strip()])
            db.session.commit()
        
        return jsonify({
            'success': True,
            'campaign': {
                'id': campaign.id,
                'name': campaign.name,
                'status': campaign.status
            }
        })
    except Exception as e:
        db.session.rollback()
        print(f"Error creating campaign: {e}")
        return jsonify({'error': 'Failed to create campaign'}), 500

@app.route('/api/campaigns/<int:campaign_id>', methods=['GET'])
@login_required
def api_campaign_details(campaign_id):
    """Get campaign details with phone numbers"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get phone numbers
        phone_numbers = CampaignPhoneNumber.query.filter_by(campaign_id=campaign_id).all()
        phone_list = []
        
        for phone in phone_numbers:
            phone_data = {
                'id': phone.id,
                'phone_number': phone.phone_number,
                'title': phone.title,
                'first_name': phone.first_name,
                'last_name': phone.last_name,
                'address_1': phone.address_1,
                'address_2': phone.address_2,
                'address_3': phone.address_3,
                'city': phone.city,
                'post_code': phone.post_code,
                'status': phone.status,
                'retry_count': phone.retry_count,
                'last_called_at': phone.last_called_at.isoformat() if phone.last_called_at else None,
                'call_id': phone.call_id,
                'disposition': phone.disposition,
                'duration': phone.duration,
                'transcript': phone.transcript,
                'notes': phone.notes,
                'created_at': phone.created_at.isoformat()
            }
            phone_list.append(phone_data)
        
        campaign_data = {
            'id': campaign.id,
            'name': campaign.name,
            'description': campaign.description,
            'status': campaign.status,
            'total_numbers': campaign.total_numbers,
            'called_numbers': campaign.called_numbers,
            'successful_calls': campaign.successful_calls,
            'failed_calls': campaign.failed_calls,
            'created_at': campaign.created_at.isoformat(),
            'updated_at': campaign.updated_at.isoformat(),
            'call_delay': campaign.call_delay,
            'max_concurrent_calls': campaign.max_concurrent_calls,
            'retry_failed_calls': campaign.retry_failed_calls,
            'max_retries': campaign.max_retries,
            'phone_numbers': phone_list
        }
        
        return jsonify(campaign_data)
    except Exception as e:
        print(f"Error fetching campaign details: {e}")
        return jsonify({'error': 'Failed to fetch campaign details'}), 500

@app.route('/api/campaigns/<int:campaign_id>/start', methods=['POST'])
@login_required
def api_start_campaign(campaign_id):
    """Start a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if campaign.status == 'active':
            return jsonify({'error': 'Campaign is already active'}), 400
        
        # Get request data
        data = request.get_json() or {}
        demo_mode = data.get('demo_mode', False)
        
        # Update campaign status
        campaign.status = 'active'
        db.session.commit()
        
        # Start the campaign process in background
        start_campaign_process(campaign_id, demo_mode)
        
        return jsonify({'success': True, 'message': 'Campaign started successfully'})
    except Exception as e:
        db.session.rollback()
        print(f"Error starting campaign: {e}")
        return jsonify({'error': 'Failed to start campaign'}), 500

@app.route('/api/campaigns/<int:campaign_id>/pause', methods=['POST'])
@login_required
def api_pause_campaign(campaign_id):
    """Pause a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        campaign.status = 'paused'
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Campaign paused successfully'})
    except Exception as e:
        db.session.rollback()
        print(f"Error pausing campaign: {e}")
        return jsonify({'error': 'Failed to pause campaign'}), 500

@app.route('/api/campaigns/<int:campaign_id>/stop', methods=['POST'])
@login_required
def api_stop_campaign(campaign_id):
    """Stop a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        campaign.status = 'completed'
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Campaign stopped successfully'})
    except Exception as e:
        db.session.rollback()
        print(f"Error stopping campaign: {e}")
        return jsonify({'error': 'Failed to stop campaign'}), 500

@app.route('/api/campaigns/<int:campaign_id>/status', methods=['GET'])
@login_required
def api_campaign_status(campaign_id):
    """Get campaign status and progress with detailed analysis"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get phone numbers with their status
        phone_numbers = CampaignPhoneNumber.query.filter_by(campaign_id=campaign_id).all()
        
        # Get call logs for this campaign
        call_logs = CampaignCallLog.query.filter_by(campaign_id=campaign_id).all()
        print(f"Debug - Found {len(call_logs)} database call logs for campaign {campaign_id}")
        
        # If no database logs, get from JSON file
        if not call_logs:
            all_calls = get_all_calls()
            total_calls = len(all_calls)
            completed_calls = len([c for c in all_calls if c.get('status') == 'ended'])
            total_duration = sum(c.get('duration', 0) for c in all_calls)
            
            # Calculate dispositions
            disposition_counts = {}
            for call in all_calls:
                disp = call.get('disposition', 'UNKNOWN')
                # Handle disposition as object or string
                if isinstance(disp, dict):
                    disp = disp.get('disposition', 'UNKNOWN')
                disposition_counts[disp] = disposition_counts.get(disp, 0) + 1
            
            # Calculate success rate based on dispositions
            # Successful: HO (Home Owner), PR (Private Renting), CALLBK (Call Back)
            # Neutral: NP (No Pitch), DAIR (Dead Air)
            # Failed: DEC (Declined), NI (Not Interested)
            successful_dispositions = ['HO', 'PR', 'CALLBK']
            neutral_dispositions = ['NP', 'DAIR']
            failed_dispositions = ['DEC', 'NI']
            
            successful_calls = sum(disposition_counts.get(disp, 0) for disp in successful_dispositions)
            neutral_calls = sum(disposition_counts.get(disp, 0) for disp in neutral_dispositions)
            failed_calls = sum(disposition_counts.get(disp, 0) for disp in failed_dispositions)
            
            # Total processed calls (excluding unknown dispositions)
            total_processed = successful_calls + neutral_calls + failed_calls
            
            status_counts = {
                'pending': 0,
                'calling': 0,
                'completed': completed_calls,
                'failed': failed_calls,
                'retry': 0
            }
        else:
            # Use database data
            status_counts = {
                'pending': 0,
                'calling': 0,
                'completed': 0,
                'failed': 0,
                'retry': 0
            }
            
            # Calculate detailed statistics
            total_duration = 0
            completed_calls = 0
            successful_calls = 0
            failed_calls = 0
            
            for phone in phone_numbers:
                status_counts[phone.status] += 1
                
                if phone.status == 'completed':
                    completed_calls += 1
                    if phone.duration:
                        total_duration += phone.duration
                    if phone.disposition and phone.disposition not in ['failed', 'error']:
                        successful_calls += 1
                elif phone.status == 'failed':
                    failed_calls += 1
        
        # Calculate analysis metrics
        avg_duration = round(total_duration / completed_calls, 1) if completed_calls > 0 else 0
        
        # Calculate success rate based on total processed calls
        total_processed_calls = successful_calls + failed_calls
        success_rate = round((successful_calls / total_processed_calls) * 100, 1) if total_processed_calls > 0 else 0
        
        # Debug: Print disposition counts
        print(f"Debug - Successful: {successful_calls}, Failed: {failed_calls}, Total: {total_processed_calls}, Success Rate: {success_rate}%")
        
        # Calculate calls per hour (simplified - based on campaign start time)
        calls_per_hour = 0
        if campaign.status == 'active' and campaign.created_at:
            from datetime import datetime, timedelta
            hours_running = (datetime.utcnow() - campaign.created_at).total_seconds() / 3600
            if hours_running > 0:
                calls_per_hour = round(completed_calls / hours_running, 1)
        
        # Use total calls from JSON if no database data
        total_contacts = len(phone_numbers) if phone_numbers else len(get_all_calls())
        
        progress = {
            'total': total_contacts,
            'pending': status_counts['pending'],
            'calling': status_counts['calling'],
            'completed': status_counts['completed'],
            'failed': status_counts['failed'],
            'retry': status_counts['retry'],
            'percentage': round((status_counts['completed'] + status_counts['failed']) / total_contacts * 100, 1) if total_contacts > 0 else 0
        }
        
        # Ensure percentage doesn't exceed 100%
        if progress['percentage'] > 100:
            progress['percentage'] = 100.0
        
        analysis = {
            'success_rate': success_rate,
            'avg_duration': avg_duration,
            'calls_per_hour': calls_per_hour,
            'total_duration': total_duration,
            'successful_calls': successful_calls,
            'failed_calls': failed_calls,
            'completed_calls': completed_calls
        }
        
        return jsonify({
            'success': True,
            'campaign': {
                'id': campaign.id,
                'name': campaign.name,
                'status': campaign.status,
                'total_numbers': total_contacts,
                'called_numbers': campaign.called_numbers,
                'successful_calls': campaign.successful_calls,
                'failed_calls': campaign.failed_calls,
                'call_delay': campaign.call_delay,
                'max_concurrent_calls': campaign.max_concurrent_calls,
                'created_at': campaign.created_at.isoformat() if campaign.created_at else None,
                'updated_at': campaign.updated_at.isoformat() if campaign.updated_at else None
            },
            'progress': progress,
            'analysis': analysis
        })
    except Exception as e:
        print(f"Error getting campaign status: {e}")
        return jsonify({'error': 'Failed to get campaign status'}), 500

@app.route('/api/campaigns/<int:campaign_id>/settings', methods=['PUT'])
@login_required
def api_update_campaign_settings(campaign_id):
    """Update campaign settings"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        data = request.get_json()
        
        # Validate and update settings with proper error handling
        if 'call_delay' in data:
            try:
                call_delay = int(data['call_delay'])
                if call_delay < 1 or call_delay > 300:
                    return jsonify({'error': 'Call delay must be between 1 and 300 seconds'}), 400
                campaign.call_delay = call_delay
            except (ValueError, TypeError):
                return jsonify({'error': 'Invalid call delay value'}), 400
                
        if 'max_concurrent_calls' in data:
            try:
                max_concurrent = int(data['max_concurrent_calls'])
                if max_concurrent < 1 or max_concurrent > 10:
                    return jsonify({'error': 'Max concurrent calls must be between 1 and 10'}), 400
                campaign.max_concurrent_calls = max_concurrent
            except (ValueError, TypeError):
                return jsonify({'error': 'Invalid max concurrent calls value'}), 400
                
        if 'retry_failed_calls' in data:
            if not isinstance(data['retry_failed_calls'], bool):
                return jsonify({'error': 'Retry failed calls must be true or false'}), 400
            campaign.retry_failed_calls = data['retry_failed_calls']
            
        if 'max_retries' in data:
            try:
                max_retries = int(data['max_retries'])
                if max_retries < 0 or max_retries > 5:
                    return jsonify({'error': 'Max retries must be between 0 and 5'}), 400
                campaign.max_retries = max_retries
            except (ValueError, TypeError):
                return jsonify({'error': 'Invalid max retries value'}), 400
        
        campaign.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Campaign settings updated successfully'})
    except Exception as e:
        db.session.rollback()
        print(f"Error updating campaign settings: {e}")
        return jsonify({'error': 'Failed to update campaign settings'}), 500

@app.route('/api/campaigns/<int:campaign_id>/add-numbers', methods=['POST'])
@login_required
def api_add_phone_numbers(campaign_id):
    """Add phone numbers to a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        data = request.get_json()
        phone_numbers = data.get('phone_numbers', [])
        
        if not phone_numbers:
            return jsonify({'error': 'Phone numbers are required'}), 400
        
        added_count = 0
        invalid_numbers = []
        
        for phone_number in phone_numbers:
            if phone_number.strip():
                # Clean and validate phone number
                cleaned_phone = clean_and_validate_phone_number(phone_number.strip())
                
                if cleaned_phone:
                    # Check if number already exists
                    existing = CampaignPhoneNumber.query.filter_by(
                        campaign_id=campaign_id, 
                        phone_number=cleaned_phone
                    ).first()
                    
                    if not existing:
                        campaign_phone = CampaignPhoneNumber(
                            phone_number=cleaned_phone,
                            campaign_id=campaign_id
                        )
                        db.session.add(campaign_phone)
                        added_count += 1
                else:
                    invalid_numbers.append(phone_number.strip())
        
        campaign.total_numbers += added_count
        db.session.commit()
        
        response_message = f'Added {added_count} phone numbers to campaign'
        if invalid_numbers:
            response_message += f'. Invalid numbers: {", ".join(invalid_numbers)}'
        
        return jsonify({
            'success': True, 
            'message': response_message,
            'added_count': added_count,
            'invalid_numbers': invalid_numbers
        })
    except Exception as e:
        db.session.rollback()
        print(f"Error adding phone numbers: {e}")
        return jsonify({'error': 'Failed to add phone numbers'}), 500

@app.route('/api/campaigns/<int:campaign_id>/add-contacts', methods=['POST'])
@login_required
def api_add_contacts(campaign_id):
    """Add contacts with full information to a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        data = request.get_json()
        contacts = data.get('contacts', [])
        
        if not contacts:
            return jsonify({'error': 'Contacts are required'}), 400
        
        added_count = 0
        invalid_contacts = []
        
        for contact in contacts:
            phone_number = contact.get('phone_number', '').strip()
            
            if not phone_number:
                invalid_contacts.append(f"Missing phone number: {contact}")
                continue
            
            # Clean and validate phone number
            cleaned_phone = clean_and_validate_phone_number(phone_number)
            
            if cleaned_phone:
                # Check if number already exists
                existing = CampaignPhoneNumber.query.filter_by(
                    campaign_id=campaign_id, 
                    phone_number=cleaned_phone
                ).first()
                
                if not existing:
                    campaign_phone = CampaignPhoneNumber(
                        phone_number=cleaned_phone,
                        title=contact.get('title', ''),
                        first_name=contact.get('first_name', ''),
                        last_name=contact.get('last_name', ''),
                        address_1=contact.get('address_1', ''),
                        address_2=contact.get('address_2', ''),
                        address_3=contact.get('address_3', ''),
                        city=contact.get('city', ''),
                        post_code=contact.get('post_code', ''),
                        campaign_id=campaign_id
                    )
                    db.session.add(campaign_phone)
                    added_count += 1
                else:
                    invalid_contacts.append(f"Duplicate phone number: {phone_number}")
            else:
                invalid_contacts.append(f"Invalid phone number format: {phone_number}")
        
        campaign.total_numbers += added_count
        db.session.commit()
        
        response_message = f'Added {added_count} contacts to campaign'
        if invalid_contacts:
            response_message += f'. Issues: {len(invalid_contacts)} contacts had problems'
        
        return jsonify({
            'success': True, 
            'message': response_message,
            'added_count': added_count,
            'invalid_contacts': invalid_contacts
        })
    except Exception as e:
        db.session.rollback()
        print(f"Error adding contacts: {e}")
        return jsonify({'error': 'Failed to add contacts'}), 500

@app.route('/api/campaigns/<int:campaign_id>/upload-contacts', methods=['POST'])
@login_required
def api_upload_contacts(campaign_id):
    """Upload contacts from CSV or Excel file"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not file:
            return jsonify({'error': 'Invalid file'}), 400
        
        # Check file extension
        filename = secure_filename(file.filename)
        file_extension = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        
        if file_extension not in ['csv', 'xlsx', 'xls']:
            return jsonify({'error': 'Only CSV and Excel files are supported'}), 400
        
        # Read the file
        try:
            if file_extension == 'csv':
                # Read CSV file
                content = file.read().decode('utf-8')
                df = pd.read_csv(io.StringIO(content))
            else:
                # Read Excel file
                df = pd.read_excel(file)
        except Exception as e:
            return jsonify({'error': f'Error reading file: {str(e)}'}), 400
        
        # Validate required columns
        required_columns = ['CONTACT NUMBER']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            return jsonify({'error': f'Missing required columns: {", ".join(missing_columns)}'}), 400
        
        # Process contacts
        added_count = 0
        invalid_contacts = []
        duplicate_count = 0
        
        for index, row in df.iterrows():
            try:
                phone_number = str(row['CONTACT NUMBER']).strip()
                
                if not phone_number or phone_number == 'nan':
                    invalid_contacts.append(f"Row {index + 1}: Missing phone number")
                    continue
                
                # Clean and validate phone number
                cleaned_phone = clean_and_validate_phone_number(phone_number)
                
                if cleaned_phone:
                    # Check if number already exists
                    existing = CampaignPhoneNumber.query.filter_by(
                        campaign_id=campaign_id, 
                        phone_number=cleaned_phone
                    ).first()
                    
                    if not existing:
                        campaign_phone = CampaignPhoneNumber(
                            phone_number=cleaned_phone,
                            title=str(row.get('TITLE', '')).strip() if pd.notna(row.get('TITLE')) else '',
                            first_name=str(row.get('FIRST NAME', '')).strip() if pd.notna(row.get('FIRST NAME')) else '',
                            last_name=str(row.get('LAST NAME', '')).strip() if pd.notna(row.get('LAST NAME')) else '',
                            address_1=str(row.get('ADDRESS 1', '')).strip() if pd.notna(row.get('ADDRESS 1')) else '',
                            address_2=str(row.get('ADDRESS 2', '')).strip() if pd.notna(row.get('ADDRESS 2')) else '',
                            address_3=str(row.get('ADDRESS 3', '')).strip() if pd.notna(row.get('ADDRESS 3')) else '',
                            city=str(row.get('CITY', '')).strip() if pd.notna(row.get('CITY')) else '',
                            post_code=str(row.get('POST CODE', '')).strip() if pd.notna(row.get('POST CODE')) else '',
                            campaign_id=campaign_id
                        )
                        db.session.add(campaign_phone)
                        added_count += 1
                    else:
                        duplicate_count += 1
                else:
                    invalid_contacts.append(f"Row {index + 1}: Invalid phone number format - {phone_number}")
            except Exception as e:
                invalid_contacts.append(f"Row {index + 1}: Error processing - {str(e)}")
        
        campaign.total_numbers += added_count
        db.session.commit()
        
        response_message = f'Successfully uploaded {added_count} contacts to campaign'
        if duplicate_count > 0:
            response_message += f'. Skipped {duplicate_count} duplicate numbers'
        if invalid_contacts:
            response_message += f'. {len(invalid_contacts)} contacts had issues'
        
        return jsonify({
            'success': True, 
            'message': response_message,
            'added_count': added_count,
            'duplicate_count': duplicate_count,
            'invalid_contacts': invalid_contacts
        })
    except Exception as e:
        db.session.rollback()
        print(f"Error uploading contacts: {e}")
        return jsonify({'error': f'Failed to upload contacts: {str(e)}'}), 500

def clean_and_validate_phone_number(phone_number):
    """
    Clean and validate phone number format
    Returns cleaned phone number if valid, None if invalid
    """
    try:
        # Remove all non-digit characters except +
        cleaned_phone = ''
        for char in phone_number:
            if char.isdigit() or char == '+':
                cleaned_phone += char
        
        # Ensure it starts with +
        if not cleaned_phone.startswith('+'):
            cleaned_phone = '+' + cleaned_phone
        
        # Validate phone number format
        if not cleaned_phone.startswith('+'):
            return None
        
        # Check for valid international phone number format (10-15 digits including country code)
        digits_only = cleaned_phone[1:]  # Remove the + sign
        if len(digits_only) < 10 or len(digits_only) > 15:
            return None
        
        # Special validation for South African numbers (+27)
        if cleaned_phone.startswith('+27'):
            # South African mobile numbers should be 9 digits after +27
            if len(digits_only) != 11:  # +27 + 9 digits = 11 total
                # Allow 11 digits for South African numbers (some may have extra digits)
                if len(digits_only) < 10 or len(digits_only) > 12:
                    return None
        
        return cleaned_phone
        
    except Exception as e:
        print(f"Error cleaning phone number {phone_number}: {e}")
        return None

@app.route('/api/campaigns/<int:campaign_id>/call-logs', methods=['GET'])
@login_required
def api_campaign_call_logs(campaign_id):
    """Get call logs for a campaign with classification data"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get call logs from database
        db_call_logs = CampaignCallLog.query.filter_by(campaign_id=campaign_id).order_by(CampaignCallLog.created_at.desc()).all()
        
        # Get all calls from JSON file for additional data
        all_calls = get_all_calls()
        
        logs_list = []
        
        # Process database call logs
        for log in db_call_logs:
            # Get classification from JSON cache if available
            classification = get_existing_classification(log.phone_number)
            
            log_data = {
                'id': f"db_{log.id}",
                'phone_number': log.phone_number,
                'call_id': log.call_id,
                'status': log.status,
                'disposition': log.disposition or (classification.get('disposition') if classification else None),
                'duration': log.duration,
                'transcript': log.transcript,
                'error_message': log.error_message,
                'created_at': log.created_at.isoformat(),
                'classification_method': classification.get('classification_method') if classification else None,
                'source': 'database'
            }
            logs_list.append(log_data)
        
        # Add calls from JSON file if no database logs exist
        if not logs_list:
            print(f"No database logs found for campaign {campaign_id}, adding JSON data")
            for i, call in enumerate(all_calls):
                try:
                    # Handle both API response format and sample data format
                    call_id = call.get('id') or call.get('call_id', f'json_{i}')
                    customer_number = call.get('customer', {}).get('number') or call.get('customer_number', 'Unknown')
                    status = call.get('status', 'ended')
                    created_at = call.get('createdAt') or call.get('created_at', 'Unknown')
                    transcript = call.get('transcript', 'No transcript available')
                    
                    # Ensure duration is properly converted to integer
                    duration = call.get('duration', 0)
                    if isinstance(duration, str):
                        try:
                            duration = int(duration)
                        except (ValueError, TypeError):
                            duration = 0
                    elif not isinstance(duration, (int, float)):
                        duration = 0
                    
                    # Use existing disposition if available, otherwise classify
                    disposition = call.get('disposition')
                    if not disposition:
                        try:
                            # Only classify if transcript is meaningful
                            if transcript and transcript != "No transcript available" and len(transcript.strip()) > 10:
                                disposition = classify_call(transcript, customer_number)
                            else:
                                disposition = "DAIR"  # Dead Air for short/no transcripts
                        except Exception as classify_error:
                            print(f"Classification failed for call {call_id}: {classify_error}")
                            disposition = "UNKNOWN"
                    
                    # Ensure disposition is a string, not an object
                    if isinstance(disposition, dict):
                        disposition = disposition.get('disposition', 'UNKNOWN')
                    elif not isinstance(disposition, str):
                        disposition = 'UNKNOWN'
                    
                    # Clean up phone number - replace "Unknown" with a more user-friendly message
                    phone_number = customer_number if customer_number != 'Unknown' else 'Private Number'
                    
                    log_data = {
                        'id': f"json_{i}",
                        'phone_number': phone_number,
                        'call_id': call_id,
                        'status': status,
                        'disposition': disposition,
                        'duration': duration,
                        'transcript': transcript,
                        'error_message': None,
                        'created_at': created_at,
                        'classification_method': 'openai' if disposition and disposition != "UNKNOWN" else 'rule_based',
                        'source': 'json'
                    }
                    
                    logs_list.append(log_data)
                    
                except Exception as call_error:
                    print(f"Error processing JSON call {i}: {call_error}")
                    continue
        
        # Sort by created_at (most recent first)
        logs_list.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        print(f"Returning {len(logs_list)} call logs for campaign {campaign_id}")
        return jsonify(logs_list)
        
    except Exception as e:
        print(f"Error fetching campaign call logs: {e}")
        return jsonify({'error': 'Failed to fetch call logs'}), 500

@app.route('/api/campaigns/<int:campaign_id>/retry-failed', methods=['POST'])
@login_required
def api_retry_failed_calls(campaign_id):
    """Retry failed calls in a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get failed phone numbers
        failed_numbers = CampaignPhoneNumber.query.filter_by(
            campaign_id=campaign_id, 
            status='failed'
        ).all()
        
        if not failed_numbers:
            return jsonify({'error': 'No failed calls to retry'}), 400
        
        # Reset failed numbers to pending
        for phone_number in failed_numbers:
            phone_number.status = 'pending'
            phone_number.retry_count += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'Reset {len(failed_numbers)} failed calls to pending status',
            'retry_count': len(failed_numbers)
        })
    except Exception as e:
        db.session.rollback()
        print(f"Error retrying failed calls: {e}")
        return jsonify({'error': 'Failed to retry failed calls'}), 500

@app.route('/api/campaigns/<int:campaign_id>', methods=['DELETE'])
@login_required
def api_delete_campaign(campaign_id):
    """API endpoint to delete a campaign"""
    print(f"🗑️ API: Delete campaign request for campaign ID: {campaign_id}")
    
    try:
        # Get the campaign
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        
        if not campaign:
            print(f"❌ Campaign {campaign_id} not found or not owned by user")
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Check if campaign is currently active
        if campaign.status == 'active':
            print(f"❌ Cannot delete active campaign {campaign_id}")
            return jsonify({'error': 'Cannot delete an active campaign. Please stop it first.'}), 400
        
        campaign_name = campaign.name
        print(f"🗑️ Deleting campaign: {campaign_name}")
        
        # Delete the campaign (this will cascade delete related records)
        db.session.delete(campaign)
        db.session.commit()
        
        print(f"✅ Campaign {campaign_name} deleted successfully")
        return jsonify({
            'success': True,
            'message': f'Campaign "{campaign_name}" deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Error deleting campaign {campaign_id}: {e}")
        return jsonify({'error': 'Failed to delete campaign'}), 500

@app.route('/api/classify-all-calls', methods=['POST'])
@login_required
def api_classify_all_calls():
    """Classify all unclassified calls using OpenAI and save to JSON"""
    try:
        # Get all calls from JSON file
        all_calls = get_all_calls()
        
        if not all_calls:
            return jsonify({
                'success': True,
                'message': 'No calls found to classify',
                'classified_count': 0
            })
        
        classified_count = 0
        results = []
        
        for call in all_calls:
            try:
                # Get call details
                call_id = call.get('id') or call.get('call_id', 'Unknown')
                customer_number = call.get('customer', {}).get('number') or call.get('customer_number', 'Unknown')
                transcript = call.get('transcript', '')
                
                # Skip if already has disposition
                if call.get('disposition'):
                    continue
                
                # Skip if no meaningful transcript
                if not transcript or transcript == "No transcript available" or len(transcript.strip()) < 10:
                    continue
                
                # Classify the call
                disposition = classify_call(transcript, customer_number)
                
                if disposition and disposition != "UNKNOWN":
                    # Update the call with disposition
                    call['disposition'] = disposition
                    classified_count += 1
                    
                    results.append({
                        'phone_number': customer_number,
                        'call_id': call_id,
                        'disposition': disposition,
                        'transcript_preview': transcript[:100] + "..." if len(transcript) > 100 else transcript
                    })
                    
                    # Save to JSON file
                    save_classification_to_json(customer_number, disposition, transcript, call_id)
                    
            except Exception as call_error:
                print(f"Error classifying call {call_id}: {call_error}")
                continue
        
        # Save updated calls back to JSON file
        try:
            with open('vapi_call_history_with_openai_classification.json', 'w') as f:
                json.dump({'call_summary': all_calls}, f, indent=2)
        except Exception as save_error:
            print(f"Error saving updated calls: {save_error}")
        
        return jsonify({
            'success': True,
            'message': f'Successfully classified {classified_count} calls',
            'classified_count': classified_count,
            'results': results
        })
        
    except Exception as e:
        print(f"Error classifying all calls: {e}")
        return jsonify({'error': 'Failed to classify calls'}), 500

@app.route('/api/call-classifications', methods=['GET'])
@login_required
def api_get_call_classifications():
    """Get all call classifications from JSON file"""
    try:
        classifications = get_all_call_classifications()
        
        if not classifications:
            return jsonify({'error': 'No classifications found'}), 404
        
        return jsonify(classifications)
        
    except Exception as e:
        print(f"Error getting call classifications: {e}")
        return jsonify({'error': 'Failed to get classifications'}), 500

@app.route('/api/campaigns/<int:campaign_id>/classify-calls', methods=['POST'])
@login_required
def api_classify_campaign_calls(campaign_id):
    """Classify all unclassified calls in a campaign using OpenAI"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get all completed calls with transcripts but no AI classification
        unclassified_calls = CampaignCallLog.query.filter_by(
            campaign_id=campaign_id,
            status='completed'
        ).filter(
            CampaignCallLog.transcript.isnot(None),
            CampaignCallLog.transcript != '',
            CampaignCallLog.transcript != 'No transcript available'
        ).all()
        
        if not unclassified_calls:
            return jsonify({
                'success': True,
                'message': 'No unclassified calls found',
                'processed': 0
            })
        
        processed_count = 0
        classification_results = []
        
        for call_log in unclassified_calls:
            try:
                # Classify the transcript using OpenAI
                print(f"🔍 Classifying call {call_log.call_id} for {call_log.phone_number}")
                ai_disposition = classify_call(call_log.transcript, call_log.phone_number)
                
                # Update the call log with AI classification
                call_log.disposition = ai_disposition
                
                # Also update the corresponding phone number if it exists
                phone_number = CampaignPhoneNumber.query.filter_by(
                    campaign_id=campaign_id,
                    phone_number=call_log.phone_number
                ).first()
                
                if phone_number:
                    phone_number.disposition = ai_disposition
                    phone_number.transcript = call_log.transcript
                
                classification_results.append({
                    'call_id': call_log.call_id,
                    'phone_number': call_log.phone_number,
                    'original_disposition': call_log.disposition,
                    'ai_disposition': ai_disposition,
                    'transcript_length': len(call_log.transcript) if call_log.transcript else 0
                })
                
                processed_count += 1
                print(f"✅ Call {call_log.call_id} classified as: {ai_disposition}")
                
            except Exception as e:
                print(f"❌ Error classifying call {call_log.call_id}: {e}")
                classification_results.append({
                    'call_id': call_log.call_id,
                    'phone_number': call_log.phone_number,
                    'error': str(e)
                })
        
        # Commit all changes
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Processed {processed_count} calls',
            'processed': processed_count,
            'total_found': len(unclassified_calls),
            'results': classification_results
        })
        
    except Exception as e:
        print(f"Error classifying campaign calls: {e}")
        return jsonify({'error': 'Failed to classify campaign calls'}), 500

@app.route('/api/campaigns/<int:campaign_id>/classification-stats', methods=['GET'])
@login_required
def api_campaign_classification_stats(campaign_id):
    """Get classification statistics for a campaign"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get all call logs for this campaign
        call_logs = CampaignCallLog.query.filter_by(campaign_id=campaign_id).all()
        
        # Count dispositions
        disposition_counts = {}
        total_calls = len(call_logs)
        calls_with_transcripts = 0
        calls_classified = 0
        
        for call_log in call_logs:
            disposition = call_log.disposition or 'Unknown'
            disposition_counts[disposition] = disposition_counts.get(disposition, 0) + 1
            
            if call_log.transcript and call_log.transcript != 'No transcript available':
                calls_with_transcripts += 1
                
            if disposition and disposition != 'Unknown':
                calls_classified += 1
        
        # Calculate percentages
        stats = {
            'campaign_id': campaign_id,
            'campaign_name': campaign.name,
            'total_calls': total_calls,
            'calls_with_transcripts': calls_with_transcripts,
            'calls_classified': calls_classified,
            'classification_rate': round((calls_classified / total_calls * 100) if total_calls > 0 else 0, 2),
            'transcript_rate': round((calls_with_transcripts / total_calls * 100) if total_calls > 0 else 0, 2),
            'disposition_breakdown': disposition_counts,
            'disposition_percentages': {}
        }
        
        # Calculate disposition percentages
        for disposition, count in disposition_counts.items():
            stats['disposition_percentages'][disposition] = round((count / total_calls * 100) if total_calls > 0 else 0, 2)
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        print(f"Error getting campaign classification stats: {e}")
        return jsonify({'error': 'Failed to get classification statistics'}), 500

@app.route('/api/campaigns/<int:campaign_id>/transcripts', methods=['GET'])
@login_required
def api_campaign_transcripts(campaign_id):
    """Get all transcripts for a campaign with Vapi integration"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get all call logs for this campaign
        call_logs = CampaignCallLog.query.filter_by(campaign_id=campaign_id).all()
        
        transcripts = []
        
        for call_log in call_logs:
            transcript_data = {
                'id': call_log.id,
                'call_id': call_log.call_id,
                'phone_number': call_log.phone_number,
                'status': call_log.status,
                'disposition': call_log.disposition,
                'duration': call_log.duration,
                'created_at': call_log.created_at.isoformat(),
                'transcript': call_log.transcript,
                'source': 'Local Database'
            }
            
            # Try to get fresh transcript from Vapi if we have a call_id
            if call_log.call_id:
                try:
                    url = f"{BASE_URL}/call/{call_log.call_id}"
                    headers = {
                        "Authorization": f"Bearer {API_KEY}",
                        "Content-Type": "application/json"
                    }
                    
                    response = requests.get(url, headers=headers, timeout=5)
                    if response.status_code == 200:
                        vapi_data = response.json()
                        vapi_transcript = vapi_data.get('transcript', '')
                        
                        if vapi_transcript and vapi_transcript != "No transcript available":
                            transcript_data['transcript'] = vapi_transcript
                            transcript_data['source'] = 'Vapi API'
                            transcript_data['vapi_status'] = vapi_data.get('status', 'Unknown')
                            transcript_data['vapi_cost'] = vapi_data.get('cost', 0)
                            
                except Exception as e:
                    print(f"Error fetching Vapi transcript for {call_log.call_id}: {e}")
                    # Keep local transcript if Vapi fails
            
            transcripts.append(transcript_data)
        
        return jsonify({
            'success': True,
            'campaign_id': campaign_id,
            'campaign_name': campaign.name,
            'total_transcripts': len(transcripts),
            'transcripts': transcripts
        })
        
    except Exception as e:
        print(f"Error getting campaign transcripts: {e}")
        return jsonify({'error': 'Failed to get campaign transcripts'}), 500

@app.route('/api/transcript-status', methods=['GET'])
@login_required
def api_transcript_status():
    """Get transcript availability status for all calls"""
    try:
        # Get all call logs from the current user's campaigns
        user_campaigns = Campaign.query.filter_by(user_id=session['user_id']).all()
        campaign_ids = [campaign.id for campaign in user_campaigns]
        
        call_logs = CampaignCallLog.query.filter(
            CampaignCallLog.campaign_id.in_(campaign_ids)
        ).all()
        
        transcript_status = []
        
        for call_log in call_logs:
            status_info = {
                'call_id': call_log.call_id,
                'phone_number': call_log.phone_number,
                'campaign_id': call_log.campaign_id,
                'has_local_transcript': bool(call_log.transcript and call_log.transcript != 'No transcript available'),
                'local_transcript_length': len(call_log.transcript) if call_log.transcript else 0,
                'status': call_log.status,
                'disposition': call_log.disposition,
                'created_at': call_log.created_at.isoformat()
            }
            
            # Check if we can get transcript from Vapi
            if call_log.call_id:
                try:
                    url = f"{BASE_URL}/call/{call_log.call_id}"
                    headers = {
                        "Authorization": f"Bearer {API_KEY}",
                        "Content-Type": "application/json"
                    }
                    
                    response = requests.get(url, headers=headers, timeout=3)
                    if response.status_code == 200:
                        vapi_data = response.json()
                        vapi_transcript = vapi_data.get('transcript', '')
                        
                        status_info['vapi_available'] = True
                        status_info['vapi_has_transcript'] = bool(vapi_transcript and vapi_transcript != 'No transcript available')
                        status_info['vapi_transcript_length'] = len(vapi_transcript) if vapi_transcript else 0
                        status_info['vapi_status'] = vapi_data.get('status', 'Unknown')
                        status_info['vapi_cost'] = vapi_data.get('cost', 0)
                    else:
                        status_info['vapi_available'] = False
                        status_info['vapi_has_transcript'] = False
                        
                except Exception as e:
                    status_info['vapi_available'] = False
                    status_info['vapi_has_transcript'] = False
                    status_info['vapi_error'] = str(e)
            else:
                status_info['vapi_available'] = False
                status_info['vapi_has_transcript'] = False
            
            transcript_status.append(status_info)
        
        return jsonify({
            'success': True,
            'total_calls': len(transcript_status),
            'calls_with_local_transcripts': sum(1 for s in transcript_status if s['has_local_transcript']),
            'calls_with_vapi_transcripts': sum(1 for s in transcript_status if s.get('vapi_has_transcript', False)),
            'transcript_status': transcript_status
        })
        
    except Exception as e:
        print(f"Error getting transcript status: {e}")
        return jsonify({'error': 'Failed to get transcript status'}), 500

@app.route('/api/campaigns/<int:campaign_id>/export', methods=['GET'])
@login_required
def api_export_campaign(campaign_id):
    """Export campaign results as CSV"""
    try:
        campaign = Campaign.query.filter_by(id=campaign_id, user_id=session['user_id']).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Get phone numbers with results
        phone_numbers = CampaignPhoneNumber.query.filter_by(campaign_id=campaign_id).all()
        
        # Create CSV content
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'CONTACT NUMBER', 'TITLE', 'FIRST NAME', 'LAST NAME', 'ADDRESS 1', 'ADDRESS 2', 'ADDRESS 3', 'CITY', 'POST CODE',
            'Status', 'Retry Count', 'Duration', 'Disposition', 'Call ID', 'Last Called', 'Notes'
        ])
        
        # Write data
        for phone in phone_numbers:
            writer.writerow([
                phone.phone_number,
                phone.title or '',
                phone.first_name or '',
                phone.last_name or '',
                phone.address_1 or '',
                phone.address_2 or '',
                phone.address_3 or '',
                phone.city or '',
                phone.post_code or '',
                phone.status,
                phone.retry_count,
                phone.duration,
                phone.disposition or '',
                phone.call_id or '',
                phone.last_called_at.isoformat() if phone.last_called_at else '',
                phone.notes or ''
            ])
        
        csv_content = output.getvalue()
        output.close()
        
        # Create response with CSV file
        from flask import Response
        response = Response(csv_content, mimetype='text/csv')
        response.headers['Content-Disposition'] = f'attachment; filename=campaign_{campaign_id}_results.csv'
        
        return response
        
    except Exception as e:
        print(f"Error exporting campaign: {e}")
        return jsonify({'error': 'Failed to export campaign'}), 500

# Global semaphore for limiting concurrent calls
import threading
campaign_semaphores = {}

def start_campaign_process(campaign_id, demo_mode=False):
    """Start the campaign calling process"""
    print(f"🚀 Starting campaign process for campaign {campaign_id}, demo_mode={demo_mode}")
    try:
        campaign = Campaign.query.get(campaign_id)
        if not campaign:
            print(f"❌ Campaign {campaign_id} not found")
            return
        if campaign.status != 'active':
            print(f"❌ Campaign {campaign_id} is not active (status: {campaign.status})")
            return
        
        print(f"✅ Campaign {campaign_id} is active, proceeding with calls")
        
        # Get or create semaphore for this campaign
        if campaign_id not in campaign_semaphores:
            campaign_semaphores[campaign_id] = threading.Semaphore(campaign.max_concurrent_calls)
        else:
            # Update semaphore if max_concurrent_calls changed
            current_semaphore = campaign_semaphores[campaign_id]
            if current_semaphore._value != campaign.max_concurrent_calls:
                campaign_semaphores[campaign_id] = threading.Semaphore(campaign.max_concurrent_calls)
        
        # Get pending phone numbers with retry logic
        if campaign.max_retries == 0:
            # If max_retries is 0, only get numbers that haven't been retried
            pending_numbers = CampaignPhoneNumber.query.filter_by(
                campaign_id=campaign_id, 
                status='pending'
            ).filter(
                CampaignPhoneNumber.retry_count == 0
            ).limit(campaign.max_concurrent_calls).all()
        else:
            # Normal retry logic
            pending_numbers = CampaignPhoneNumber.query.filter_by(
                campaign_id=campaign_id, 
                status='pending'
            ).filter(
                CampaignPhoneNumber.retry_count < campaign.max_retries
            ).limit(campaign.max_concurrent_calls).all()
        
        print(f"📞 Found {len(pending_numbers)} pending numbers to call")
        
        if not pending_numbers:
            # No more numbers to call, mark campaign as completed
            print(f"📊 No pending numbers found, marking campaign {campaign_id} as completed")
            campaign.status = 'completed'
            db.session.commit()
            return
        
        for phone_number in pending_numbers:
            # Acquire semaphore to limit concurrent calls
            semaphore = campaign_semaphores.get(campaign_id)
            if semaphore:
                semaphore.acquire()
            
            # Update status to calling
            phone_number.status = 'calling'
            phone_number.last_called_at = datetime.utcnow()
            db.session.commit()
            
            # Make the call
            try:
                if demo_mode:
                    # Simulate a demo call
                    import uuid
                    import time
                    call_id = str(uuid.uuid4())
                    
                    # Simulate call duration and result
                    time.sleep(2)  # Simulate call time
                    
                    phone_number.call_id = call_id
                    phone_number.status = 'completed'
                    phone_number.duration = 120  # 2 minutes
                    phone_number.disposition = 'NP'  # No Pitch
                    phone_number.transcript = f'Demo call to {phone_number.phone_number}. This was a simulated call for testing purposes. The AI assistant would normally have a conversation with the customer here.'
                    
                    # Log the demo call
                    call_log = CampaignCallLog(
                        campaign_id=campaign_id,
                        phone_number=phone_number.phone_number,
                        call_id=call_id,
                        status='completed',
                        disposition='NP',
                        duration=120,
                        transcript=phone_number.transcript
                    )
                    db.session.add(call_log)
                    
                    campaign.called_numbers += 1
                    campaign.successful_calls += 1
                    
                else:
                    # Make real call - ensure phone number is properly formatted
                    cleaned_phone = clean_and_validate_phone_number(phone_number.phone_number)
                    if cleaned_phone:
                        result = make_single_call(cleaned_phone)
                    else:
                        # Invalid phone number format
                        phone_number.retry_count += 1
                        if phone_number.retry_count >= campaign.max_retries:
                            phone_number.status = 'failed'
                            campaign.failed_calls += 1
                        else:
                            phone_number.status = 'pending'  # Retry later
                        
                        # Log the failed call
                        call_log = CampaignCallLog(
                            campaign_id=campaign_id,
                            phone_number=phone_number.phone_number,
                            status='failed',
                            error_message='Invalid phone number format'
                        )
                        db.session.add(call_log)
                        result = None
                    
                    if result and result.get('id'):
                        phone_number.call_id = result['id']
                        phone_number.status = 'completed'
                        
                        # Log the call
                        call_log = CampaignCallLog(
                            campaign_id=campaign_id,
                            phone_number=phone_number.phone_number,
                            call_id=result['id'],
                            status='initiated'
                        )
                        db.session.add(call_log)
                        
                        campaign.called_numbers += 1
                        campaign.successful_calls += 1
                        
                        # Schedule transcript processing and classification
                        def process_call_transcript_and_classify():
                            import time
                            time.sleep(5)  # Wait for transcript to be available
                            
                            with app.app_context():
                                try:
                                    # Get call status and transcript
                                    call_status_url = f"{BASE_URL}/call/{result['id']}"
                                    headers = {
                                        "Authorization": f"Bearer {API_KEY}",
                                        "Content-Type": "application/json"
                                    }
                                    
                                    status_response = requests.get(call_status_url, headers=headers)
                                    if status_response.status_code == 200:
                                        call_data = status_response.json()
                                        transcript = call_data.get('transcript', '')
                                        duration = call_data.get('duration', 0)
                                        disposition = call_data.get('disposition', '')
                                        
                                        # Update call log with transcript
                                        call_log.transcript = transcript
                                        call_log.duration = duration
                                        call_log.disposition = disposition
                                        
                                        # Classify the call using OpenAI
                                        if transcript and transcript != "No transcript available":
                                            print(f"🔍 Classifying call {result['id']} for {phone_number.phone_number}")
                                            ai_disposition = classify_call(transcript, phone_number.phone_number)
                                            
                                            # Update both phone number and call log with AI classification
                                            phone_number.disposition = ai_disposition
                                            phone_number.transcript = transcript
                                            phone_number.duration = duration
                                            call_log.disposition = ai_disposition
                                            
                                            print(f"✅ Call {result['id']} classified as: {ai_disposition}")
                                        else:
                                            # No transcript available, use original disposition
                                            phone_number.disposition = disposition
                                            phone_number.transcript = transcript
                                            phone_number.duration = duration
                                        
                                        db.session.commit()
                                        print(f"💾 Updated call {result['id']} with transcript and classification")
                                        
                                except Exception as e:
                                    print(f"❌ Error processing transcript for call {result['id']}: {e}")
                        
                        # Start transcript processing in background
                        transcript_thread = threading.Thread(target=process_call_transcript_and_classify)
                        transcript_thread.daemon = True
                        transcript_thread.start()
                    else:
                        # Handle failed call with retry logic
                        phone_number.retry_count += 1
                        if phone_number.retry_count >= campaign.max_retries:
                            phone_number.status = 'failed'
                            campaign.failed_calls += 1
                        else:
                            phone_number.status = 'pending'  # Retry later
                        
                        # Log the failed call
                        call_log = CampaignCallLog(
                            campaign_id=campaign_id,
                            phone_number=phone_number.phone_number,
                            status='failed',
                            error_message='Failed to initiate call'
                        )
                        db.session.add(call_log)
                
            except Exception as e:
                # Handle exception with retry logic
                phone_number.retry_count += 1
                if phone_number.retry_count >= campaign.max_retries:
                    phone_number.status = 'failed'
                    campaign.failed_calls += 1
                else:
                    phone_number.status = 'pending'  # Retry later
                
                # Log the error
                call_log = CampaignCallLog(
                    campaign_id=campaign_id,
                    phone_number=phone_number.phone_number,
                    status='failed',
                    error_message=str(e)
                )
                db.session.add(call_log)
            
            db.session.commit()
            
            # Release semaphore after call processing
            if semaphore:
                semaphore.release()
        
        # Schedule next batch of calls with proper delay
        if campaign.status == 'active':
            import time
            
            # Use a more accurate timer for call delay
            def schedule_next_batch():
                time.sleep(campaign.call_delay)  # More accurate than Timer
                # Use application context for database operations
                with app.app_context():
                    if campaign.status == 'active':  # Check if still active
                        start_campaign_process(campaign_id, demo_mode)
            
            # Start the timer in a separate thread
            timer_thread = threading.Thread(target=schedule_next_batch)
            timer_thread.daemon = True
            timer_thread.start()
    
    except Exception as e:
        print(f"Error in campaign process: {e}")
        # Mark campaign as failed if we have access to campaign object
        try:
            if 'campaign' in locals():
                campaign.status = 'failed'
                db.session.commit()
        except:
            print("Could not update campaign status due to context error")

def classify_call(transcript, phone_number=None):
    """
    Classify call using OpenAI GPT for more accurate classification
    First checks if phone number has already been classified in JSON file
    """
    if not transcript or transcript == "No transcript available":
        return "DAIR"  # Dead Air - no transcript available
    
    # Check cache first to prevent repeated API calls
    cache_key = f"{phone_number}_{hash(transcript)}" if phone_number else hash(transcript)
    if cache_key in classification_cache:
        print(f"Using cached classification for {phone_number or 'transcript'}: {classification_cache[cache_key]}")
        return classification_cache[cache_key]
    
    # If phone number is provided, check if it's already classified in JSON
    if phone_number:
        existing_classification = get_existing_classification(phone_number)
        if existing_classification:
            print(f"Using existing classification for {phone_number}: {existing_classification}")
            # Cache the result
            classification_cache[cache_key] = existing_classification
            return existing_classification
    
    # Check if OpenAI API key is available and valid
    if not OPENAI_API_KEY or OPENAI_API_KEY == "your-openai-api-key":
        print("OpenAI API key not configured, using rule-based classification")
        return classify_call_rule_based(transcript)
    
    # Set up OpenAI client
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
    except Exception as e:
        print(f"Failed to initialize OpenAI client: {e}")
        return classify_call_rule_based(transcript)
    
    # Limit transcript length to prevent excessive API usage
    if len(transcript) > 1000:
        transcript = transcript[:1000] + "..."
    
    # Define the classification prompt with better examples
    classification_prompt = f"""
Analyze this call transcript and classify it into exactly one of these categories:

A - Answering Machine (voicemail, leave message, after the beep)
B - Busy (busy signal, line busy, try again later)
CALLBK - Call Back (customer asks to call back, schedule callback)
DAIR - Dead Air (very short call, no meaningful conversation)
DC - Disconnected Number (number not in service, invalid number)
DEC - Declined Sale (customer says no, not interested in purchase)
DNC - Do Not Call (customer asks to stop calling, remove from list)
N - No Answer (no one picks up, rings without answer)
NI - Not Interested (customer expresses disinterest)
NP - No Pitch No Price (general conversation, service call, no sales attempt)
SALE - Sale Made (customer agrees to purchase, shows interest)
XFER - Call Transferred (call gets transferred to someone else)
CHU - Customer Hung Up (customer ends call abruptly)
DNQ - Do Not Qualify (customer doesn't meet criteria for survey/service)
HO - Home Owner (customer owns their home)
PR - Private Renting (customer rents from private landlord)
SL - Scotland (customer is in Scotland)
WN - Wrong Number (wrong person, not the right number)

Call Transcript:
{transcript}

Respond with ONLY the classification code (e.g., "NP", "SALE", "CALLBK") - no other text.
"""
    
    try:
        print(f"Calling OpenAI API for transcript: {transcript[:100]}...")
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a call classification expert. Your task is to analyze call transcripts and return ONLY the appropriate classification code from the provided list. Do not include any explanations, punctuation, or additional text - just the code."},
                {"role": "user", "content": classification_prompt}
            ],
            max_tokens=5,
            temperature=0.0,
            timeout=10  # Add timeout to prevent hanging
        )
        
        classification = response.choices[0].message.content.strip().upper()
        
        # Debug: Print what OpenAI returned
        print(f"OpenAI returned: '{classification}'")
        
        # Validate the classification
        valid_codes = ["A", "B", "CALLBK", "DAIR", "DC", "DEC", "DNC", "N", "NI", "NP", "SALE", "XFER", "CHU", "DNQ", "HO", "PR", "SL", "WN"]
        
        if classification in valid_codes:
            # Cache the result
            classification_cache[cache_key] = classification
            # Save to JSON for future reference
            save_classification_to_json(phone_number, classification, transcript)
            return classification
        else:
            # Try to extract a valid code from the response
            for code in valid_codes:
                if code in classification:
                    # Cache the result
                    classification_cache[cache_key] = code
                    # Save to JSON for future reference
                    save_classification_to_json(phone_number, code, transcript)
                    return code
                    return code
            print(f"Could not extract valid code from: '{classification}'")
            # Cache the unknown result
            classification_cache[cache_key] = "UNKNOWN"
            return "UNKNOWN"
            
    except Exception as e:
        print(f"OpenAI classification failed: {e}")
        print(f"Error type: {type(e)}")
        # Fallback to rule-based classification if OpenAI fails
        fallback_classification = classify_call_rule_based(transcript)
        # Cache the fallback result
        classification_cache[cache_key] = fallback_classification
        return fallback_classification

def get_existing_classification(phone_number):
    """
    Check if phone number has already been classified in the JSON file
    Returns the classification if found, None otherwise
    """
    try:
        with open('call_classifications.json', 'r') as f:
            data = json.load(f)
        
        # Look for the phone number in classifications
        if phone_number in data.get('classifications', {}):
            classification_data = data['classifications'][phone_number]
            disposition = classification_data.get('disposition')
            if disposition:
                print(f"Found existing classification for {phone_number}: {disposition}")
                return {
                    'disposition': disposition,
                    'classification_method': classification_data.get('classification_method', 'unknown')
                }
        
        print(f"No existing classification found for {phone_number}")
        return None
        
    except FileNotFoundError:
        print(f"Classification JSON file not found")
        return None
    except Exception as e:
        print(f"Error reading classification JSON: {e}")
        return None

def save_classification_to_json(phone_number, disposition, transcript, call_id=None, campaign_id=None):
    """
    Save classification result to JSON file for future reference
    """
    try:
        # Load existing data or create new structure
        try:
            with open('call_classifications.json', 'r') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # If file doesn't exist or is corrupted, create new structure
            data = {
                "metadata": {
                    "created_at": datetime.utcnow().isoformat(),
                    "total_classifications": 0,
                    "last_updated": datetime.utcnow().isoformat()
                },
                "classifications": {}
            }
        
        # Add or update classification
        data['classifications'][phone_number] = {
            "disposition": disposition,
            "transcript": transcript,
            "call_id": call_id,
            "campaign_id": campaign_id,
            "classified_at": datetime.utcnow().isoformat(),
            "classification_method": "openai" if disposition and isinstance(disposition, str) and "openai" in disposition.lower() else "rule_based"
        }
        
        # Update metadata
        data['metadata']['total_classifications'] = len(data['classifications'])
        data['metadata']['last_updated'] = datetime.utcnow().isoformat()
        
        # Save to file with proper error handling
        try:
            with open('call_classifications.json', 'w') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"✅ Classification saved to JSON for {phone_number}: {disposition}")
            return True
        except Exception as write_error:
            print(f"❌ Error writing to JSON file: {write_error}")
            return False
        
    except Exception as e:
        print(f"❌ Error saving classification to JSON: {e}")
        return False

def get_all_call_classifications():
    """
    Get all call classifications from JSON file
    """
    try:
        with open('call_classifications.json', 'r') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        return {
            "metadata": {
                "created_at": datetime.utcnow().isoformat(),
                "total_classifications": 0,
                "last_updated": datetime.utcnow().isoformat()
            },
            "classifications": {}
        }
    except json.JSONDecodeError as e:
        print(f"Error reading classifications JSON: {e}")
        # Return empty structure if file is corrupted
        return {
            "metadata": {
                "created_at": datetime.utcnow().isoformat(),
                "total_classifications": 0,
                "last_updated": datetime.utcnow().isoformat()
            },
            "classifications": {}
        }
    except Exception as e:
        print(f"Error reading classifications: {e}")
        return None

def classify_call_rule_based(transcript):
    """
    Fallback rule-based classification when OpenAI is not available
    """
    if not transcript or transcript == "No transcript available":
        return "DAIR"  # Dead Air - no transcript available
    
    transcript_lower = transcript.lower()
    
    # Check for answering machine indicators
    if any(phrase in transcript_lower for phrase in [
        "leave a message", "after the beep", "answering machine", "voicemail",
        "record your message", "beep", "leave your message"
    ]):
        return "A"  # Answering Machine
    
    # Check for call back requests (check this BEFORE busy signals)
    if any(phrase in transcript_lower for phrase in [
        "call back", "call me back", "call you back", "callback", "call back tomorrow",
        "call back later", "schedule a callback", "call back at"
    ]):
        return "CALLBK"  # Call Back
    
    # Check for busy signals
    if any(phrase in transcript_lower for phrase in [
        "busy", "line is busy", "call back later", "try again later"
    ]):
        return "B"  # Busy
    
    # Check for disconnected numbers
    if any(phrase in transcript_lower for phrase in [
        "number you have dialed", "no longer in service", "disconnected",
        "number is not available", "invalid number"
    ]):
        return "DC"  # Disconnected Number
    
    # Check for declined sales
    if any(phrase in transcript_lower for phrase in [
        "not interested", "not currently interested", "not right now",
        "don't want to", "not looking for", "not in the market"
    ]):
        return "DEC"  # Declined Sale
    
    # Check for do not call requests
    if any(phrase in transcript_lower for phrase in [
        "do not call", "don't call", "stop calling", "remove me from your list",
        "take me off your list", "never call again"
    ]):
        return "DNC"  # Do Not Call
    
    # Check for no answer (very short or no meaningful conversation)
    if len(transcript.strip()) < 20 or transcript_lower.count("hello") == 0:
        return "N"  # No Answer
    
    # Check for not interested
    if any(phrase in transcript_lower for phrase in [
        "not interested", "not right now", "not at this time", "maybe later"
    ]):
        return "NI"  # Not Interested
    
    # Check for sales made
    if any(phrase in transcript_lower for phrase in [
        "yes, i'm interested", "that sounds good", "i'll take it", "sign me up",
        "let's proceed", "i want to", "i'd like to", "order summary", "total comes to"
    ]):
        return "SALE"  # Sale Made
    
    # Check for call transfers
    if any(phrase in transcript_lower for phrase in [
        "transfer", "transferring", "put you through", "connect you with"
    ]):
        return "XFER"  # Call Transferred
    
    # Check for customer hung up
    if any(phrase in transcript_lower for phrase in [
        "goodbye", "bye", "hang up", "end call", "thank you, bye"
    ]) and len(transcript_lower.split()) < 100:
        return "CHU"  # Customer Hung Up
    
    # Check for do not qualify (survey specific)
    if any(phrase in transcript_lower for phrase in [
        "this survey only applies", "doesn't apply to you", "not eligible",
        "only applies to", "can't continue with the survey"
    ]):
        return "DNQ"  # Do Not Qualify
    
    # Check for home owner
    if any(phrase in transcript_lower for phrase in [
        "i own it", "i own my home", "homeowner", "own my home"
    ]):
        return "HO"  # Home Owner
    
    # Check for private renting
    if any(phrase in transcript_lower for phrase in [
        "private landlord", "private renting", "private tenant"
    ]):
        return "PR"  # Private Renting
    
    # Check for Scotland
    if "scotland" in transcript_lower or "scottish" in transcript_lower:
        return "SL"  # Scotland
    
    # Check for wrong number
    if any(phrase in transcript_lower for phrase in [
        "wrong number", "wrong person", "not the right person", "you have the wrong"
    ]):
        return "WN"  # Wrong Number
    
    # Check for dead air (very short or no meaningful conversation)
    if len(transcript.strip()) < 50 or transcript_lower.count("hello") > 2:
        return "DAIR"  # Dead Air
    
    # Default classification for successful conversations
    if len(transcript.strip()) > 100:
        return "NP"  # No Pitch No Price (general conversation)
    
    return "DAIR"  # Dead Air as default

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000) 