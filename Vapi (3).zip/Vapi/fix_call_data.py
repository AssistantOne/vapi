#!/usr/bin/env python3
"""
Fix Call Data in Database
"""

import requests
from datetime import datetime
from app import app, db, CampaignCallLog, CampaignPhoneNumber, API_KEY, BASE_URL

def fix_call_data():
    """Fix the call data for the specific call"""
    call_id = "02d34f88-9e13-4d2a-9c91-8da4b5d1b789"
    
    print(f"🔧 Fixing call data for: {call_id}")
    
    # Get call data from Vapi API
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    url = f"{BASE_URL}/call/{call_id}"
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        call_data = response.json()
        
        print(f"📋 Call Data from Vapi:")
        print(f"  Status: {call_data.get('status')}")
        print(f"  Started At: {call_data.get('startedAt')}")
        print(f"  Ended At: {call_data.get('endedAt')}")
        print(f"  Phone Number: {call_data.get('customer', {}).get('number')}")
        print(f"  Cost: ${call_data.get('cost')}")
        print(f"  Transcript Available: {'Yes' if call_data.get('transcript') else 'No'}")
        
        # Calculate duration
        duration = 0
        if call_data.get('startedAt') and call_data.get('endedAt'):
            try:
                start_time = datetime.fromisoformat(call_data['startedAt'].replace('Z', '+00:00'))
                end_time = datetime.fromisoformat(call_data['endedAt'].replace('Z', '+00:00'))
                duration = int((end_time - start_time).total_seconds())
                print(f"  Calculated Duration: {duration} seconds")
            except Exception as e:
                print(f"  Error calculating duration: {e}")
        
        # Get transcript
        transcript = call_data.get('transcript', '')
        
        # Classify the transcript
        from app import classify_call
        disposition_result = classify_call(transcript, call_data.get('customer', {}).get('number'))
        # Handle both string and dict returns
        if isinstance(disposition_result, dict):
            disposition = disposition_result.get('disposition', 'UNKNOWN')
        else:
            disposition = disposition_result
        print(f"  Classification: {disposition}")
        
        # Update database
        with app.app_context():
            # Update CampaignCallLog
            call_log = CampaignCallLog.query.filter_by(call_id=call_id).first()
            if call_log:
                print(f"📝 Updating CampaignCallLog...")
                call_log.status = call_data.get('status', 'unknown')
                call_log.duration = duration
                call_log.transcript = transcript
                call_log.disposition = disposition
                print(f"  ✅ CampaignCallLog updated")
            else:
                print(f"❌ CampaignCallLog not found for call_id: {call_id}")
            
            # Update CampaignPhoneNumber
            phone_number = call_data.get('customer', {}).get('number')
            if phone_number:
                phone_record = CampaignPhoneNumber.query.filter_by(phone_number=phone_number).first()
                if phone_record:
                    print(f"📱 Updating CampaignPhoneNumber...")
                    phone_record.status = 'completed' if call_data.get('status') == 'ended' else 'calling'
                    phone_record.duration = duration
                    phone_record.transcript = transcript
                    phone_record.disposition = disposition
                    phone_record.call_id = call_id
                    print(f"  ✅ CampaignPhoneNumber updated")
                else:
                    print(f"❌ CampaignPhoneNumber not found for: {phone_number}")
            
            # Commit changes
            try:
                db.session.commit()
                print(f"✅ Database updated successfully!")
            except Exception as e:
                print(f"❌ Error committing to database: {e}")
                db.session.rollback()
        
        print(f"\n🎉 Call data fixed!")
        print(f"  Status: {call_data.get('status')}")
        print(f"  Duration: {duration} seconds")
        print(f"  Disposition: {disposition}")
        print(f"  Transcript: {'Available' if transcript else 'Not Available'}")
        
    else:
        print(f"❌ Error getting call data: {response.status_code}")
        print(f"Response: {response.text}")

if __name__ == "__main__":
    fix_call_data() 