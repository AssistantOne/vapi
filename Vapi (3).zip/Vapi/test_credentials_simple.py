#!/usr/bin/env python3
"""
Simple Vapi Credentials Test
"""

import requests
import json
from app import API_KEY, ASSISTANT_ID, PHONE_NUMBER_ID, BASE_URL

def test_credentials():
    """Simple test of Vapi credentials"""
    print("🔍 Testing Vapi API Credentials...")
    print(f"API Key: {API_KEY[:10]}...")
    print(f"Assistant ID: {ASSISTANT_ID}")
    print(f"Phone Number ID: {PHONE_NUMBER_ID}")
    print(f"Base URL: {BASE_URL}")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test 1: Assistant
    print("\n📋 Testing Assistant...")
    try:
        response = requests.get(f"{BASE_URL}/assistant/{ASSISTANT_ID}", headers=headers, timeout=10)
        if response.status_code == 200:
            assistant = response.json()
            print(f"✅ Assistant: {assistant.get('name', 'Unknown')}")
        else:
            print(f"❌ Assistant Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Assistant Exception: {e}")
        return False
    
    # Test 2: Phone Number
    print("\n📱 Testing Phone Number...")
    try:
        response = requests.get(f"{BASE_URL}/phone-number/{PHONE_NUMBER_ID}", headers=headers, timeout=10)
        if response.status_code == 200:
            phone = response.json()
            print(f"✅ Phone Number: {phone.get('number', 'Unknown')}")
        else:
            print(f"❌ Phone Number Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Phone Number Exception: {e}")
        return False
    
    # Test 3: Simple call creation test
    print("\n📞 Testing Call Endpoint...")
    try:
        test_payload = {
            "assistantId": ASSISTANT_ID,
            "phoneNumberId": PHONE_NUMBER_ID,
            "customer": {
                "number": "+1234567890"
            }
        }
        response = requests.post(f"{BASE_URL}/call", json=test_payload, headers=headers, timeout=10)
        if response.status_code in [200, 201, 400, 422]:
            print("✅ Call endpoint accessible")
            if response.status_code in [400, 422]:
                print("   (Expected validation error for test number)")
        else:
            print(f"❌ Call endpoint error: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Call endpoint exception: {e}")
        return False
    
    print("\n🎉 All tests passed! Credentials are working correctly.")
    return True

if __name__ == "__main__":
    success = test_credentials()
    if success:
        print("\n✅ Vapi API credentials are valid and ready to use!")
    else:
        print("\n❌ Vapi API credentials have issues.") 