#!/usr/bin/env python3
"""
Test Classification Directly
"""

from app import classify_call, clear_classification_cache

def test_classification():
    """Test classification for the specific call"""
    
    # Clear the cache first
    clear_classification_cache()
    
    # The actual transcript from the call
    transcript = """AI: Hello. My name is Emma calling from the damp and disrepair survey team. We're helping UK tenants whose council or housing association hasn't fixed major issue like damp or leaks, It's just a 1 minute survey. Is now a good time?
User: Yes.
AI: Great. Just to start, are you based in England or Wales?
User: England.
AI: Perfect. And just checking, do you own your home or are you renting from a council or housing association?
User: Irene.
AI: It sounds like you might have mentioned a name there. Just clarify, are you a homeowner, or do you rent from a council or housing association?
User: I rinse from the console.
AI: Thank you for clarifying that you rent from the council. Got it? And how many people are in your household?
User: Sorry. You think you could you could call me back at another time? I'm a bit busy right now.
AI: No worries at all. I can definitely call you back later. When would be best for you?
User: Tomorrow at 3 PM?
AI: Tomorrow at 3 PM works perfectly. I'll make sure to call you back then. Thank you for your time, and I hope you have a great day.
User: Okay."""
    
    phone_number = "+27630243757"
    
    print("🔍 Testing Classification Directly")
    print(f"Phone Number: {phone_number}")
    print(f"Transcript Length: {len(transcript)} characters")
    
    # Test classification
    try:
        disposition = classify_call(transcript, phone_number)
        print(f"✅ Classification Result: {disposition}")
        
        # Test rule-based classification directly
        from app import classify_call_rule_based
        rule_based_result = classify_call_rule_based(transcript)
        print(f"🔧 Rule-based Result: {rule_based_result}")
        
        # Check for callback phrases
        transcript_lower = transcript.lower()
        callback_phrases = [
            "call back", "call me back", "call you back", "callback", "call back tomorrow",
            "call back later", "schedule a callback", "call back at"
        ]
        
        print(f"\n🔍 Checking for callback phrases:")
        for phrase in callback_phrases:
            if phrase in transcript_lower:
                print(f"  ✅ Found: '{phrase}'")
            else:
                print(f"  ❌ Not found: '{phrase}'")
        
        # Check for answering machine phrases
        am_phrases = [
            "leave a message", "after the beep", "answering machine", "voicemail",
            "record your message", "beep", "leave your message"
        ]
        
        print(f"\n🔍 Checking for answering machine phrases:")
        for phrase in am_phrases:
            if phrase in transcript_lower:
                print(f"  ✅ Found: '{phrase}'")
            else:
                print(f"  ❌ Not found: '{phrase}'")
        
    except Exception as e:
        print(f"❌ Classification error: {e}")

if __name__ == "__main__":
    test_classification() 