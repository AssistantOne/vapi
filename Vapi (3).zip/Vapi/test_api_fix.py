import requests
import json

# Test the API endpoint that was failing
def test_api_fix():
    print("🧪 Testing API fix...")
    
    # Test data
    test_data = {
        "phone_number": "+27630243757",
        "demo_mode": False
    }
    
    try:
        # Make a request to the API endpoint
        response = requests.post(
            "http://localhost:5000/api/make-call",
            json=test_data,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
        print(f"📊 Response Status: {response.status_code}")
        print(f"📊 Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ API call successful!")
            print(f"📋 Response: {json.dumps(result, indent=2)}")
            return True
        else:
            print(f"❌ API call failed with status {response.status_code}")
            print(f"🔍 Error response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Exception during API call: {e}")
        return False

if __name__ == "__main__":
    test_api_fix() 