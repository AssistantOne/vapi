#!/usr/bin/env python3
"""
Clear Classification Cache
"""

import os
import json

def clear_cache():
    """Clear all classification cache files"""
    
    # Clear the classification cache
    try:
        from app import clear_classification_cache
        clear_classification_cache()
        print("✅ Classification cache cleared")
    except Exception as e:
        print(f"❌ Error clearing classification cache: {e}")
    
    # Remove the JSON file if it exists
    json_file = 'call_classifications.json'
    if os.path.exists(json_file):
        try:
            os.remove(json_file)
            print(f"✅ Removed {json_file}")
        except Exception as e:
            print(f"❌ Error removing {json_file}: {e}")
    else:
        print(f"ℹ️  {json_file} not found")
    
    # Clear the classification_cache dictionary
    try:
        from app import classification_cache
        classification_cache.clear()
        print("✅ classification_cache dictionary cleared")
    except Exception as e:
        print(f"❌ Error clearing classification_cache: {e}")

if __name__ == "__main__":
    clear_cache() 