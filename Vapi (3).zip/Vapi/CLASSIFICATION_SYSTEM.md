# OpenAI Call Classification System

## Overview

The Vapi application now includes an advanced call classification system that uses OpenAI's GPT model to automatically classify call dispositions based on call transcripts. This system provides more accurate and consistent classification compared to rule-based methods.

## Pipeline

The classification pipeline follows this flow:

```
Call Transcript → OpenAI GPT → Classification → Database Update → Display Results
```

## Classification Categories

The system classifies calls into the following categories:

| Code | Description |
|------|-------------|
| A | Answering Machine (voicemail, leave message, after the beep) |
| B | Busy (busy signal, line busy, try again later) |
| CALLBK | Call Back (customer asks to call back, schedule callback) |
| DAIR | Dead Air (very short call, no meaningful conversation) |
| DC | Disconnected Number (number not in service, invalid number) |
| DEC | Declined Sale (customer says no, not interested in purchase) |
| DNC | Do Not Call (customer asks to stop calling, remove from list) |
| N | No Answer (no one picks up, rings without answer) |
| NI | Not Interested (customer expresses disinterest) |
| NP | No Pitch No Price (general conversation, service call, no sales attempt) |
| SALE | Sale Made (customer agrees to purchase, shows interest) |
| XFER | Call Transferred (call gets transferred to someone else) |
| CHU | Customer Hung Up (customer ends call abruptly) |
| DNQ | Do Not Qualify (customer doesn't meet criteria for survey/service) |
| HO | Home Owner (customer owns their home) |
| PR | Private Renting (customer rents from private landlord) |
| SL | Scotland (customer is in Scotland) |
| WN | Wrong Number (wrong person, not the right number) |

## API Endpoints

### 1. Classify Individual Transcript
**POST** `/api/classify-transcript`

Classify a single transcript using OpenAI.

**Request Body:**
```json
{
    "transcript": "Hello, this is John calling about our services...",
    "phone_number": "+1234567890",
    "call_id": "call_123"
}
```

**Response:**
```json
{
    "success": true,
    "disposition": "NP",
    "transcript": "Hello, this is John calling about our services...",
    "phone_number": "+1234567890",
    "call_id": "call_123",
    "classification_method": "OpenAI"
}
```

### 2. Classify Call by ID
**POST** `/api/classify-call/<call_id>`

Get call transcript from Aventus Voice Hub API and classify it.

**Response:**
```json
{
    "success": true,
    "call_id": "call_123",
    "phone_number": "+1234567890",
    "transcript": "Hello, this is John calling...",
    "duration": 120,
    "original_disposition": "Unknown",
    "ai_disposition": "NP",
    "classification_method": "OpenAI"
}
```

### 3. Classify Campaign Calls
**POST** `/api/campaigns/<campaign_id>/classify-calls`

Classify all unclassified calls in a campaign.

**Response:**
```json
{
    "success": true,
    "message": "Processed 15 calls",
    "processed": 15,
    "total_found": 15,
    "results": [
        {
            "call_id": "call_123",
            "phone_number": "+1234567890",
            "original_disposition": "Unknown",
            "ai_disposition": "NP",
            "transcript_length": 150
        }
    ]
}
```

### 4. Get Classification Statistics
**GET** `/api/campaigns/<campaign_id>/classification-stats`

Get classification statistics for a campaign.

**Response:**
```json
{
    "success": true,
    "stats": {
        "campaign_id": 1,
        "campaign_name": "Test Campaign",
        "total_calls": 100,
        "calls_with_transcripts": 85,
        "calls_classified": 80,
        "classification_rate": 80.0,
        "transcript_rate": 85.0,
        "disposition_breakdown": {
            "NP": 25,
            "SALE": 15,
            "DNC": 10,
            "DAIR": 20,
            "N": 10
        },
        "disposition_percentages": {
            "NP": 25.0,
            "SALE": 15.0,
            "DNC": 10.0,
            "DAIR": 20.0,
            "N": 10.0
        }
    }
}
```

### 5. Enhanced Call Status
**GET** `/api/call-status/<call_id>`

Get call status with AI classification included.

**Response:**
```json
{
    "status": "completed",
    "phone_number": "+1234567890",
    "duration": 120,
    "original_disposition": "Unknown",
    "transcript": "Hello, this is John calling...",
    "cost": 0.05,
    "call_id": "call_123",
    "ai_classification": {
        "disposition": "NP",
        "method": "OpenAI",
        "available": true
    }
}
```

## Automatic Classification

The system automatically classifies calls in the following scenarios:

1. **Campaign Calls**: When a campaign call is completed, the system automatically retrieves the transcript and classifies it after a 5-second delay.

2. **Real-time Classification**: The call status endpoint now includes AI classification results.

3. **Batch Processing**: Campaign calls can be classified in bulk using the campaign classification endpoint.

## Caching

The system includes intelligent caching to prevent repeated API calls:

- **Classification Cache**: Results are cached by phone number and transcript hash
- **API Response Cache**: Call data is cached for 15-30 seconds
- **JSON Storage**: Classifications are saved to JSON files for persistence

## Fallback System

If OpenAI is unavailable or fails, the system falls back to rule-based classification using predefined patterns and keywords.

## Configuration

### OpenAI API Key
Set your OpenAI API key in the `app.py` file:
```python
OPENAI_API_KEY = "your-openai-api-key-here"
```

### Model Settings
The system uses GPT-3.5-turbo with the following settings:
- Temperature: 0.0 (deterministic responses)
- Max tokens: 5 (for classification codes only)
- Timeout: 10 seconds

## Testing

Run the test script to verify the classification system:
```bash
python test_classification.py
```

## Error Handling

The system handles various error scenarios:
- OpenAI API failures
- Invalid transcripts
- Network timeouts
- Rate limiting
- Invalid classification codes

## Performance Considerations

- Transcripts are limited to 1000 characters to prevent excessive API usage
- Results are cached to reduce API calls
- Background processing prevents blocking the main application
- Fallback to rule-based classification ensures reliability

## Monitoring

The system provides detailed logging:
- Classification attempts and results
- API call success/failure
- Cache hits and misses
- Error details for debugging

## Future Enhancements

Potential improvements:
- Custom classification models
- Multi-language support
- Sentiment analysis
- Confidence scores
- Batch API calls for efficiency 