#!/usr/bin/env python3
"""
Test Call Data Processing
"""

import requests
import json
from datetime import datetime
from app import API_KEY, BASE_URL

def test_call_data():
    """Test call data processing for the specific call"""
    call_id = "02d34f88-9e13-4d2a-9c91-8da4b5d1b789"
    
    print(f"🔍 Testing call data for: {call_id}")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Get call data from Vapi
    url = f"{BASE_URL}/call/{call_id}"
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        call_data = response.json()
        
        print("\n📋 Raw Call Data:")
        print(f"Status: {call_data.get('status')}")
        print(f"Started At: {call_data.get('startedAt')}")
        print(f"Ended At: {call_data.get('endedAt')}")
        print(f"Duration (from API): {call_data.get('duration')}")
        print(f"Phone Number: {call_data.get('customer', {}).get('number')}")
        print(f"Cost: ${call_data.get('cost')}")
        print(f"Transcript Available: {'Yes' if call_data.get('transcript') else 'No'}")
        
        # Calculate duration
        duration = 0
        if call_data.get('startedAt') and call_data.get('endedAt'):
            try:
                start_time = datetime.fromisoformat(call_data['startedAt'].replace('Z', '+00:00'))
                end_time = datetime.fromisoformat(call_data['endedAt'].replace('Z', '+00:00'))
                duration = int((end_time - start_time).total_seconds())
                print(f"Calculated Duration: {duration} seconds")
            except Exception as e:
                print(f"Error calculating duration: {e}")
        
        # Test transcript
        transcript = call_data.get('transcript', '')
        if transcript:
            print(f"\n📝 Transcript Preview:")
            print(transcript[:200] + "..." if len(transcript) > 200 else transcript)
            
            # Test classification
            print(f"\n🤖 Testing Classification:")
            from app import classify_call
            try:
                disposition = classify_call(transcript, call_data.get('customer', {}).get('number'))
                print(f"Classified as: {disposition}")
            except Exception as e:
                print(f"Classification error: {e}")
        else:
            print("\n❌ No transcript available")
        
        # Test our API endpoint
        print(f"\n🌐 Testing our API endpoint:")
        try:
            from app import app
            with app.test_client() as client:
                # Simulate login (you might need to adjust this)
                response = client.get(f'/api/call-status/{call_id}')
                if response.status_code == 200:
                    data = response.get_json()
                    print(f"Our API Status: {data.get('status')}")
                    print(f"Our API Duration: {data.get('duration')}")
                    print(f"Our API Transcript: {'Available' if data.get('transcript') else 'Not Available'}")
                    print(f"Our API AI Classification: {data.get('ai_classification', {}).get('disposition')}")
                else:
                    print(f"Our API Error: {response.status_code}")
        except Exception as e:
            print(f"Error testing our API: {e}")
        
    else:
        print(f"❌ Error getting call data: {response.status_code}")
        print(f"Response: {response.text}")

if __name__ == "__main__":
    test_call_data() 