#!/usr/bin/env python3
"""
Vapi API Credentials Diagnostic and Fix Tool
"""

import requests
import json
from app import API_KEY, BASE_URL

def test_api_key():
    """Test if the API key is valid"""
    print("🔑 Testing API Key...")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test with a simple endpoint
    try:
        response = requests.get(f"{BASE_URL}/assistant", headers=headers, timeout=10)
        if response.status_code == 200:
            print("✅ API Key is valid!")
            return True
        else:
            print(f"❌ API Key test failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ API Key test error: {e}")
        return False

def list_assistants():
    """List all available assistants"""
    print("\n🤖 Listing all assistants...")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/assistant", headers=headers, timeout=10)
        if response.status_code == 200:
            assistants = response.json()
            print(f"✅ Found {len(assistants)} assistants:")
            
            for i, assistant in enumerate(assistants, 1):
                print(f"   {i}. ID: {assistant['id']}")
                print(f"      Name: {assistant.get('name', 'Unknown')}")
                print(f"      Created: {assistant.get('createdAt', 'Unknown')}")
                print()
            
            return assistants
        else:
            print(f"❌ Failed to list assistants: {response.status_code}")
            return []
    except Exception as e:
        print(f"❌ Error listing assistants: {e}")
        return []

def list_phone_numbers():
    """List all available phone numbers"""
    print("\n📱 Listing all phone numbers...")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/phone-number", headers=headers, timeout=10)
        if response.status_code == 200:
            phone_numbers = response.json()
            print(f"✅ Found {len(phone_numbers)} phone numbers:")
            
            for i, phone in enumerate(phone_numbers, 1):
                print(f"   {i}. ID: {phone['id']}")
                print(f"      Number: {phone.get('phoneNumber', 'Unknown')}")
                print(f"      Name: {phone.get('name', 'Unknown')}")
                print(f"      Country: {phone.get('country', 'Unknown')}")
                print()
            
            return phone_numbers
        else:
            print(f"❌ Failed to list phone numbers: {response.status_code}")
            print(f"Response: {response.text}")
            return []
    except Exception as e:
        print(f"❌ Error listing phone numbers: {e}")
        return []

def check_account_balance():
    """Check account balance and credits"""
    print("\n💰 Checking account balance...")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/account", headers=headers, timeout=10)
        if response.status_code == 200:
            account = response.json()
            print("✅ Account information:")
            print(f"   Balance: ${account.get('balance', 'Unknown')}")
            print(f"   Credits: {account.get('credits', 'Unknown')}")
            print(f"   Plan: {account.get('plan', 'Unknown')}")
            return account
        else:
            print(f"❌ Failed to get account info: {response.status_code}")
            return None
    except Exception as e:
        print(f"❌ Error checking account: {e}")
        return None

def test_specific_credentials(assistant_id, phone_number_id):
    """Test specific assistant and phone number IDs"""
    print(f"\n🔍 Testing specific credentials...")
    print(f"Assistant ID: {assistant_id}")
    print(f"Phone Number ID: {phone_number_id}")
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test Assistant
    try:
        response = requests.get(f"{BASE_URL}/assistant/{assistant_id}", headers=headers, timeout=10)
        if response.status_code == 200:
            assistant = response.json()
            print(f"✅ Assistant found: {assistant.get('name', 'Unknown')}")
        else:
            print(f"❌ Assistant not found: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Assistant test error: {e}")
        return False
    
    # Test Phone Number
    try:
        response = requests.get(f"{BASE_URL}/phone-number/{phone_number_id}", headers=headers, timeout=10)
        if response.status_code == 200:
            phone = response.json()
            print(f"✅ Phone Number found: {phone.get('phoneNumber', 'Unknown')}")
            return True
        else:
            print(f"❌ Phone Number not found: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Phone Number test error: {e}")
        return False

def generate_config_file(assistant_id, phone_number_id):
    """Generate a new config section for app.py"""
    print(f"\n📝 Generating new configuration...")
    
    config = f'''# Aventus Voice Hub API Configuration
API_KEY = "{API_KEY}"
ASSISTANT_ID = "{assistant_id}"  # Replace with your assistant ID
PHONE_NUMBER_ID = "{phone_number_id}"  # Replace with your phone number ID
BASE_URL = "https://api.vapi.ai"
'''
    
    print("Copy this configuration to your app.py file:")
    print("=" * 50)
    print(config)
    print("=" * 50)
    
    # Save to file
    with open('vapi_config.txt', 'w') as f:
        f.write(config)
    
    print("Configuration also saved to 'vapi_config.txt'")

def main():
    """Main diagnostic function"""
    print("🚀 Vapi API Credentials Diagnostic Tool")
    print("=" * 50)
    
    # Test API key first
    if not test_api_key():
        print("\n❌ API Key is invalid. Please check your API key.")
        return
    
    # Check account balance
    account = check_account_balance()
    if account and account.get('balance', 0) <= 0:
        print("\n⚠️  Warning: Low or zero balance detected!")
        print("   You may need to add credits to your account.")
    
    # List assistants
    assistants = list_assistants()
    
    # List phone numbers
    phone_numbers = list_phone_numbers()
    
    # Test current credentials
    print(f"\n🔍 Testing current credentials from app.py...")
    from app import ASSISTANT_ID, PHONE_NUMBER_ID
    
    current_works = test_specific_credentials(ASSISTANT_ID, PHONE_NUMBER_ID)
    
    if current_works:
        print("\n✅ Current credentials are working!")
    else:
        print("\n❌ Current credentials have issues.")
        
        if assistants and phone_numbers:
            print("\n💡 Suggested fixes:")
            
            # Suggest first assistant
            if assistants:
                suggested_assistant = assistants[0]['id']
                print(f"   Assistant ID: {suggested_assistant}")
            
            # Suggest first phone number
            if phone_numbers:
                suggested_phone = phone_numbers[0]['id']
                print(f"   Phone Number ID: {suggested_phone}")
            
            # Generate new config
            if assistants and phone_numbers:
                generate_config_file(assistants[0]['id'], phone_numbers[0]['id'])
    
    print("\n📋 Summary:")
    print(f"   API Key: {'✅ Valid' if test_api_key() else '❌ Invalid'}")
    print(f"   Assistants: {len(assistants)} found")
    print(f"   Phone Numbers: {len(phone_numbers)} found")
    print(f"   Current Config: {'✅ Working' if current_works else '❌ Issues'}")
    
    if account:
        print(f"   Account Balance: ${account.get('balance', 'Unknown')}")

if __name__ == "__main__":
    main() 