#!/usr/bin/env python3
"""
Test script for Vapi transcript functionality
"""

import requests
import json

# Test configuration
BASE_URL = "http://localhost:5000"

def test_transcript_endpoints():
    """Test the transcript-related API endpoints"""
    print("🧪 Testing Vapi Transcript Functionality")
    print("=" * 50)
    
    # First, we need to login (you'll need to create a test user first)
    login_data = {
        "username": "testuser",
        "password": "testpass"
    }
    
    try:
        # Test login (you may need to create a test user first)
        login_response = requests.post(f"{BASE_URL}/login", data=login_data, allow_redirects=False)
        
        if login_response.status_code != 302:  # Not redirected, login failed
            print("⚠️  Login failed. Please create a test user first or use existing credentials.")
            print("   You can create a test user by registering at /register")
            return
        
        # Get session cookies
        cookies = login_response.cookies
        
        print("✅ Login successful")
        print()
        
        # Test 1: Get transcript status
        print("📊 Test 1: Getting transcript status...")
        response = requests.get(f"{BASE_URL}/api/transcript-status", cookies=cookies)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                print(f"   ✅ Total calls: {data['total_calls']}")
                print(f"   ✅ Calls with local transcripts: {data['calls_with_local_transcripts']}")
                print(f"   ✅ Calls with Vapi transcripts: {data['calls_with_vapi_transcripts']}")
                
                # Show some sample transcript status
                if data['transcript_status']:
                    sample = data['transcript_status'][0]
                    print(f"   📝 Sample call: {sample['phone_number']}")
                    print(f"      Local transcript: {'Yes' if sample['has_local_transcript'] else 'No'}")
                    print(f"      Vapi transcript: {'Yes' if sample.get('vapi_has_transcript', False) else 'No'}")
            else:
                print(f"   ❌ Failed: {data.get('error')}")
        else:
            print(f"   ❌ API call failed: {response.status_code}")
        
        print()
        
        # Test 2: Get campaigns to test campaign-specific endpoints
        print("📋 Test 2: Getting campaigns...")
        response = requests.get(f"{BASE_URL}/api/campaigns", cookies=cookies)
        
        if response.status_code == 200:
            campaigns = response.json()
            if campaigns:
                campaign_id = campaigns[0]['id']
                print(f"   ✅ Found campaign: {campaigns[0]['name']} (ID: {campaign_id})")
                
                # Test 3: Get campaign transcripts
                print(f"📝 Test 3: Getting transcripts for campaign {campaign_id}...")
                response = requests.get(f"{BASE_URL}/api/campaigns/{campaign_id}/transcripts", cookies=cookies)
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('success'):
                        print(f"   ✅ Total transcripts: {data['total_transcripts']}")
                        
                        if data['transcripts']:
                            sample = data['transcripts'][0]
                            print(f"   📝 Sample transcript: {sample['phone_number']}")
                            print(f"      Source: {sample['source']}")
                            print(f"      Length: {len(sample['transcript']) if sample['transcript'] else 0} chars")
                            print(f"      Preview: {sample['transcript'][:100] if sample['transcript'] else 'None'}...")
                    else:
                        print(f"   ❌ Failed: {data.get('error')}")
                else:
                    print(f"   ❌ API call failed: {response.status_code}")
            else:
                print("   ⚠️  No campaigns found")
        else:
            print(f"   ❌ API call failed: {response.status_code}")
        
        print()
        
        # Test 4: Test individual transcript endpoint
        print("🔍 Test 4: Testing individual transcript endpoint...")
        # This would need a real call ID, so we'll just test the endpoint structure
        print("   ℹ️  Individual transcript endpoint: /api/call-transcript/<call_id>")
        print("   ℹ️  This endpoint fetches transcripts directly from Vapi API")
        
        print()
        print("🏁 Transcript functionality tests completed!")
        
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to the application.")
        print("   Make sure the Flask app is running on http://localhost:5000")
    except Exception as e:
        print(f"❌ Error during testing: {e}")

def test_vapi_integration():
    """Test Vapi API integration directly"""
    print("🔗 Testing Vapi API Integration")
    print("=" * 50)
    
    # Test Vapi API credentials
    from app import API_KEY, BASE_URL
    
    print(f"🔑 Testing Vapi API connection...")
    print(f"   Base URL: {BASE_URL}")
    print(f"   API Key: {API_KEY[:10]}..." if API_KEY else "   API Key: Not set")
    
    try:
        # Test Vapi API connection
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        
        # Try to get recent calls
        response = requests.get(f"{BASE_URL}/calls", headers=headers, timeout=10)
        
        if response.status_code == 200:
            calls = response.json()
            print(f"   ✅ Vapi API connection successful")
            print(f"   📞 Found {len(calls)} calls")
            
            if calls:
                # Test getting transcript for first call
                first_call = calls[0]
                call_id = first_call.get('id')
                
                if call_id:
                    print(f"   🔍 Testing transcript retrieval for call {call_id}...")
                    transcript_response = requests.get(f"{BASE_URL}/call/{call_id}", headers=headers, timeout=10)
                    
                    if transcript_response.status_code == 200:
                        call_data = transcript_response.json()
                        transcript = call_data.get('transcript', '')
                        
                        print(f"   ✅ Call transcript retrieved")
                        print(f"   📝 Transcript length: {len(transcript)} chars")
                        print(f"   📝 Has transcript: {'Yes' if transcript and transcript != 'No transcript available' else 'No'}")
                        
                        if transcript and transcript != 'No transcript available':
                            print(f"   📝 Preview: {transcript[:100]}...")
                    else:
                        print(f"   ❌ Failed to get transcript: {transcript_response.status_code}")
                else:
                    print("   ⚠️  No call ID found in first call")
            else:
                print("   ⚠️  No calls found")
        else:
            print(f"   ❌ Vapi API connection failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except Exception as e:
        print(f"   ❌ Error testing Vapi API: {e}")

if __name__ == "__main__":
    print("🚀 Vapi Transcript Integration Test Suite")
    print("=" * 50)
    print()
    
    # Test Vapi API integration first
    test_vapi_integration()
    print()
    
    # Then test the application endpoints
    test_transcript_endpoints() 